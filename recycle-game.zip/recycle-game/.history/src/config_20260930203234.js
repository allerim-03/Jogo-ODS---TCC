// ==========================================
// CONFIGURAÇÕES, BANCO DE DADOS E ESTADOS
// ==========================================

export const canvas = document.getElementById("telaJogo");
export const ctx = canvas.getContext("2d");

// Botões Centrais e Menus
export const botaoStart = { id: "START", x: 280, y: 250, largura: 240, altura: 50 }; // Subimos ele
export const botaoTutorial = { id: "TUTORIAL", x: 280, y: 320, largura: 115, altura: 40 }; // Menor
export const botaoConfig = { id: "CONFIG", x: 405, y: 320, largura: 115, altura: 40 }; // Menor

export const botaoPausaHUD = { id: "PAUSA", x: 360, y: 15, largura: 80, altura: 25 }; 
export const botaoRetomar = { id: "RETOMAR", x: 280, y: 200, largura: 240, altura: 50 };
export const botaoVoltarFases = { id: "VOLTAR_FASES", x: 280, y: 270, largura: 240, altura: 50 };
export const botaoVoltarMenu = { id: "VOLTAR_MENU", x: 280, y: 340, largura: 240, altura: 50 };

// Botão geral de voltar para as telas secundárias
export const botaoVoltar = { id: "VOLTAR_GERAL", x: 280, y: 360, largura: 240, altura: 45 };

// Botões de configuração de som (+ e -)
export const btnMusicaMenos = { id: "MUS_MENOS", x: 300, y: 170, largura: 40, altura: 40 };
export const btnMusicaMais = { id: "MUS_MAIS", x: 460, y: 170, largura: 40, altura: 40 };
export const btnEfeitosMenos = { id: "EFX_MENOS", x: 300, y: 260, largura: 40, altura: 40 };
export const btnEfeitosMais = { id: "EFX_MAIS", x: 460, y: 260, largura: 40, altura: 40 };

// Controle de Volume
export let volumeMusica = 50;
export let volumeEfeitos = 50;
export function setVolumeMusica(v) { volumeMusica = Math.max(0, Math.min(100, v)); }
export function setVolumeEfeitos(v) { volumeEfeitos = Math.max(0, Math.min(100, v)); }

// 5 Botões de Fases perfeitamente espaçados horizontalmente
export const botoesFases = [
    { id: "FASE_1", fase: 1, x: 75,  y: 180, largura: 70, altura: 70, cor: "#EF4444" }, 
    { id: "FASE_2", fase: 2, x: 220, y: 180, largura: 70, altura: 70, cor: "#3B82F6" }, 
    { id: "FASE_3", fase: 3, x: 365, y: 180, largura: 70, altura: 70, cor: "#10B981" }, 
    { id: "FASE_4", fase: 4, x: 510, y: 180, largura: 70, altura: 70, cor: "#78350F" },
    { id: "FASE_5", fase: 5, x: 655, y: 180, largura: 70, altura: 70, cor: "#A855F7" }  
];

export let jogoScale = 4; 
export let NUM_LINHAS = 3;
export let esteiraY = 90;
export let posicoesLinhas = []; 

export let estadoJogo = "MENU"; 
export let faseAtual = 1;
export let pontos = 0;
export let vidas = 3;
export let fasesDesbloqueadas = { 1: true, 2: false, 3: false, 4: false, 5: false };

export let botaoHover = null; 
export function setBotaoHover(novoBotao) { botaoHover = novoBotao; }

export let lixeirasAtivas = [];
export let listaLixos = [];
export let lixosColetados = {};
export let metasColeta = {};
export let totalLixosNecessarios = 0; 
export let totalLixosColetadosFase = 0;
export let frameEsteiraAnima = 0;
export let tempoUltimoFrame = 0;
export let lixoSelecionado = null;
export let arrastando = false;

function carregarImagem(caminho) {
    const img = new Image();
    img.isReady = false; // Trava de segurança criada por nós
    img.onload = () => { img.isReady = true; }; // Só libera se carregar de verdade
    img.onerror = () => { img.isReady = false; console.warn("Imagem não encontrada: " + caminho); };
    img.src = caminho;
    return img;
}

const imgPlastico = carregarImagem("assets/Lixeiras/lixeira_plastico.png");
const imgPapel = carregarImagem("assets/Lixeiras/lixeira_papel.png");
const imgVidro = carregarImagem("assets/Lixeiras/lixeira_vidro.png");
const imgMetal = carregarImagem("assets/Lixeiras/lixeira_metal.png");
const imgOrganico = carregarImagem("assets/Lixeiras/lixeira_organico.png");

const imgLixoMetal = carregarImagem("assets/Lixos/lixo_metal.png");
const imgLixoOrganico = carregarImagem("assets/Lixos/lixo_organico.png");
const imgLixoPapel = carregarImagem("assets/Lixos/lixo_papel.png");
const imgLixoPlastico1 = carregarImagem("assets/Lixos/lixo_plástico1.png");
const imgLixoVidro1 = carregarImagem("assets/Lixos/lixo_vidro1.png");
const imgLixoVidro2 = carregarImagem("assets/Lixos/lixo_vidro2.png");

export const bancoDadosJogo = [
    { 
        nome: "Plástico", cor: "#EF4444", pontos: 50, dano: 1, imagem: imgPlastico,
        imagensLixo: [imgLixoPlastico1]
    },
    { 
        nome: "Papel", cor: "#3B82F6", pontos: 20, dano: 1, imagem: imgPapel,
        imagensLixo: [imgLixoPapel]
    },
    { 
        nome: "Vidro", cor: "#10B981", pontos: 50, dano: 1, imagem: imgVidro,
        imagensLixo: [imgLixoVidro1, imgLixoVidro2]
    },
    { 
        nome: "Metal", cor: "#F59E0B", pontos: 30, dano: 1, imagem: imgMetal,
        imagensLixo: [imgLixoMetal]
    },
    { 
        nome: "Orgânico", cor: "#78350F", pontos: 10, dano: 1, imagem: imgOrganico,
        imagensLixo: [imgLixoOrganico]
    }
];

export function setEstadoJogo(novoEstado) { estadoJogo = novoEstado; }
export function setFaseAtual(novaFase) { faseAtual = novaFase; }
export function setPontos(novosPontos) { pontos = novosPontos; }
export function setVidas(novasVidas) { vidas = novasVidas; }
export function setJogoScale(novaScale) { jogoScale = novaScale; }
export function setNumLinhas(novoNum) { NUM_LINHAS = novoNum; }
export function setEsteiraY(novoY) { esteiraY = novoY; }
export function setPosicoesLinhas(novasPosicoes) { posicoesLinhas = novasPosicoes; }
export function setLixeirasAtivas(novasLixeiras) { lixeirasAtivas = novasLixeiras; }
export function setListaLixos(novaLista) { listaLixos = novaLista; }
export function setTotalLixosNecessarios(novoTotal) { totalLixosNecessarios = novoTotal; }
export function setTotalLixosColetadosFase(novoTotal) { totalLixosColetadosFase = novoTotal; }
export function setFrameEsteiraAnima(novoFrame) { frameEsteiraAnima = novoFrame; }
export function setTempoUltimoFrame(novoTempo) { tempoUltimoFrame = novoTempo; }
export function setLixoSelecionado(novoLixo) { lixoSelecionado = novoLixo; }
export function setArrastando(valor) { arrastando = valor; }
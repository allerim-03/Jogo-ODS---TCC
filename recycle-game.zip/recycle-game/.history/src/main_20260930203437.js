// ==========================================
// MOTOR PRINCIPAL, REGRAS DO JOGO E LOOP (60 FPS)
// ==========================================

import { 
    canvas, ctx, estadoJogo, setEstadoJogo, faseAtual, setFaseAtual, pontos, setPontos, 
    vidas, setVidas, jogoScale, NUM_LINHAS, setNumLinhas, esteiraY, setEsteiraY, 
    posicoesLinhas, setPosicoesLinhas, lixeirasAtivas, setLixeirasAtivas, 
    listaLixos, setListaLixos, lixosColetados, metasColeta, setTotalLixosNecessarios, 
    setTotalLixosColetadosFase, totalLixosColetadosFase, fasesDesbloqueadas, 
    bancoDadosJogo, arrastando, lixoSelecionado 
} from './config.js';

import { 
    desenharMenu, desenharSelecaoFases, desenharPartida, 
    desenharMenuPausa, desenharGameOver, desenharVitoria,
    desenharTutorial, desenharConfig // <-- ADICIONADOS AQUI
} from './render.js';

import './controls.js';

// ==========================================
// LÓGICA DE GERENCIAMENTO DE FASES
// ==========================================
export function carregarFase(fase) {
    setFaseAtual(fase);
    setPontos(0);
    setListaLixos([]);
    setTotalLixosColetadosFase(0);
    setVidas((fase === 5) ? 1 : 3); // Fase 5 é a infinita
    
    for (let info of bancoDadosJogo) {
        lixosColetados[info.cor.toLowerCase()] = 0;
    }
    
    setNumLinhas(3); 
    setEsteiraY(90);
    
    let novasLinhas = [];
    let novasLixeiras = [];
    let novoTotalNecessario = 0;

    for (let i = 0; i < NUM_LINHAS; i++) {
        let faixaPixelStartY = 3 + i * 19; 
        let yFaixaExato = esteiraY + (faixaPixelStartY * jogoScale) + (4 * jogoScale);
        novasLinhas.push(yFaixaExato);
    }

    let lixeirasDaFaseIndices = [];
    if (fase === 1) lixeirasDaFaseIndices = [0, 1]; 
    if (fase === 2) lixeirasDaFaseIndices = [0, 1, 2]; 
    if (fase === 3) lixeirasDaFaseIndices = [0, 1, 2, 3]; 
    if (fase >= 4) lixeirasDaFaseIndices = [0, 1, 2, 3, 4]; // Fase 4 normal e Fase 5 Infinita usam 5 lixeiras

    let metaPorLixeira = fase === 1 ? 4 : (fase === 2 ? 6 : (fase === 3 ? 8 : 10));
    if (fase === 5) metaPorLixeira = 999;

    let larguraLixeiraPixels = 24 * jogoScale;
    let numLixeiras = lixeirasDaFaseIndices.length;
    let espacoPorLixeira = canvas.width / numLixeiras;

    for (let i = 0; i < numLixeiras; i++) {
        let info = bancoDadosJogo[lixeirasDaFaseIndices[i]];
        let lixX = (i * espacoPorLixeira) + (espacoPorLixeira / 2) - (larguraLixeiraPixels / 2);
        let lixY = canvas.height - larguraLixeiraPixels - 10; 
        
        novasLixeiras.push({
            nome: info.nome, cor: info.cor.toLowerCase(), spriteInfo: info,
            x: lixX, y: lixY, largura: larguraLixeiraPixels, altura: larguraLixeiraPixels
        });
        
        metasColeta[info.cor.toLowerCase()] = metaPorLixeira; 
        novoTotalNecessario += metaPorLixeira;
    }
    
    setPosicoesLinhas(novasLinhas);
    setLixeirasAtivas(novasLixeiras);
    setTotalLixosNecessarios(novoTotalNecessario);
    setEstadoJogo("JOGANDO");
}

window.addEventListener("lixoSoltoNaLixeira", (evento) => {
    let { lixo, lixeira } = evento.detail;
    let corDoLixo = lixo.sprite.cor.toLowerCase();
    let corDaLixeira = lixeira.cor.toLowerCase();

    if (corDoLixo === corDaLixeira) {
        setPontos(pontos + lixo.sprite.pontos);
        lixosColetados[corDoLixo] = (lixosColetados[corDoLixo] || 0) + 1;
        setTotalLixosColetadosFase(totalLixosColetadosFase + 1);
        
        let venceu = true;
        for (let lix of lixeirasAtivas) {
            let c = lix.cor.toLowerCase();
            if ((lixosColetados[c] || 0) < metasColeta[c]) venceu = false;
        }
        
        if (venceu && faseAtual < 5) {
            fasesDesbloqueadas[faseAtual + 1] = true;
            setEstadoJogo("VITORIA");
        }
    } else {
        setVidas(vidas - lixo.sprite.dano);
        if (vidas <= 0) setEstadoJogo("GAMEOVER");
    }

    let index = listaLixos.indexOf(lixo);
    if (index > -1) listaLixos.splice(index, 1);
});

window.addEventListener("trocarFase", (evento) => {
    carregarFase(evento.detail);
});

// ==========================================
// CRIAÇÃO DINÂMICA DE LIXOS (HORIZONTAL)
// ==========================================
function criarLixo() {
    if (estadoJogo !== "JOGANDO" || vidas <= 0) return; 

    let lixeiraSorteada = lixeirasAtivas[Math.floor(Math.random() * lixeirasAtivas.length)];
    let linhaSorteadaY = posicoesLinhas[Math.floor(Math.random() * posicoesLinhas.length)];
    
    // Sorteia uma imagem específica dentro das variações daquele tipo de material
    let variacoes = lixeiraSorteada.spriteInfo.imagensLixo;
    let arteSorteada = variacoes[Math.floor(Math.random() * variacoes.length)];
    
    listaLixos.push({
        x: -50, 
        y: linhaSorteadaY, 
        sprite: lixeiraSorteada.spriteInfo, // Mantém a referência aos status/dano
        imagemLixo: arteSorteada, // A imagem exata que vai ser desenhada
        velocidade: 1.5 + (faseAtual * 0.4) 
    });
}

let intervaloLixo = setInterval(criarLixo, 1800);

// ==========================================
// LOOP DE ATUALIZAÇÃO REGRAS E RENDERIZAÇÃO
// ==========================================
function atualizarJogo(timestamp) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (estadoJogo === "JOGANDO") {
        for (let i = 0; i < listaLixos.length; i++) {
            let l = listaLixos[i];
            
            if (l !== lixoSelecionado) {
                l.x += l.velocidade; 
            }

            if (l.x >= canvas.width) {
                setVidas(vidas - l.sprite.dano);
                if (vidas <= 0) {
                    setVidas(0);
                    setEstadoJogo("GAMEOVER");
                }
                listaLixos.splice(i, 1); 
                i--;
            }
        }
    }

    if (estadoJogo === "MENU") desenharMenu(timestamp);
    else if (estadoJogo === "SELECAO_FASES") desenharSelecaoFases(timestamp);
    else if (estadoJogo === "JOGANDO") desenharPartida(timestamp);
    else if (estadoJogo === "PAUSA") desenharMenuPausa(timestamp);
    else if (estadoJogo === "GAMEOVER") desenharGameOver(timestamp);
    else if (estadoJogo === "VITORIA") desenharVitoria(timestamp);
    else if (estadoJogo === "TUTORIAL") desenharTutorial(timestamp); // <-- NOVA
    else if (estadoJogo === "CONFIG") desenharConfig(timestamp);
    
    requestAnimationFrame(atualizarJogo);
}

atualizarJogo(0);
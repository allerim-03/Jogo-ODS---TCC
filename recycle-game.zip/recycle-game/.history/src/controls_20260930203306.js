import { 
    canvas, estadoJogo, setEstadoJogo, 
    botaoStart, botaoTutorial, botaoConfig, botaoVoltar, botoesFases, 
    botaoPausaHUD, botaoRetomar, botaoVoltarFases, botaoVoltarMenu,
    btnMusicaMenos, btnMusicaMais, btnEfeitosMenos, btnEfeitosMais,
    volumeMusica, volumeEfeitos, setVolumeMusica, setVolumeEfeitos,
    fasesDesbloqueadas, listaLixos, jogoScale, posicoesLinhas,
    lixeirasAtivas, setLixoSelecionado, setArrastando, lixoSelecionado, arrastando,
    setBotaoHover
} from './config.js';

function pegarPosicaoMao(evento) {
    const rect = canvas.getBoundingClientRect();
    let cX = evento.clientX, cY = evento.clientY;
    if (evento.touches && evento.touches.length > 0) {
        cX = evento.touches[0].clientX; cY = evento.touches[0].clientY;
    } else if (evento.changedTouches && evento.changedTouches.length > 0) {
        cX = evento.changedTouches[0].clientX; cY = evento.changedTouches[0].clientY;
    }
    return { 
        x: (cX - rect.left) * (canvas.width / rect.width), 
        y: (cY - rect.top) * (canvas.height / rect.height) 
    };
}

function clicou(pos, b) {
    return pos.x >= b.x && pos.x <= b.x + b.largura && pos.y >= b.y && pos.y <= b.y + b.altura;
}

function aoIniciarToque(evento) {
    if (evento.cancelable) evento.preventDefault();
    const pos = pegarPosicaoMao(evento);

    if (estadoJogo === "MENU") {
        if (clicou(pos, botaoStart)) setEstadoJogo("SELECAO_FASES");
        else if (clicou(pos, botaoTutorial)) setEstadoJogo("TUTORIAL");
        else if (clicou(pos, botaoConfig)) setEstadoJogo("CONFIG");
        return;
    }

    if (estadoJogo === "SELECAO_FASES") {
        if (clicou(pos, botaoVoltar)) { setEstadoJogo("MENU"); return; }
        for (let b of botoesFases) {
            if (clicou(pos, b) && fasesDesbloqueadas[b.fase]) {
                const eventoFase = new CustomEvent("trocarFase", { detail: b.fase });
                window.dispatchEvent(eventoFase);
                break;
            }
        }
        return;
    }

    if (estadoJogo === "TUTORIAL") {
        if (clicou(pos, botaoVoltar)) setEstadoJogo("MENU");
        return;
    }

    if (estadoJogo === "CONFIG") {
        if (clicou(pos, btnMusicaMenos)) setVolumeMusica(volumeMusica - 10);
        else if (clicou(pos, btnMusicaMais)) setVolumeMusica(volumeMusica + 10);
        else if (clicou(pos, btnEfeitosMenos)) setVolumeEfeitos(volumeEfeitos - 10);
        else if (clicou(pos, btnEfeitosMais)) setVolumeEfeitos(volumeEfeitos + 10);
        else if (clicou(pos, botaoVoltar)) setEstadoJogo("MENU");
        return;
    }

    if (estadoJogo === "JOGANDO") {
        if (clicou(pos, botaoPausaHUD)) { setEstadoJogo("PAUSA"); return; }
        let margemErro = 15;
        for (let i = listaLixos.length - 1; i >= 0; i--) {
            let l = listaLixos[i];
            if (pos.x >= l.x - margemErro && pos.x <= l.x + (16 * jogoScale) + margemErro && 
                pos.y >= l.y - margemErro && pos.y <= l.y + (16 * jogoScale) + margemErro) {
                setLixoSelecionado(l); setArrastando(true); break;
            }
        }
    }
    
    if (estadoJogo === "PAUSA") {
        if (clicou(pos, botaoRetomar)) setEstadoJogo("JOGANDO");
        else if (clicou(pos, botaoVoltarFases)) setEstadoJogo("SELECAO_FASES");
        else if (clicou(pos, botaoVoltarMenu)) setEstadoJogo("MENU");
        return;
    }

    if (estadoJogo === "GAMEOVER" || estadoJogo === "VITORIA") setEstadoJogo("SELECAO_FASES");
}

function aoMovimentarMouseHUD(evento) {
    const pos = pegarPosicaoMao(evento);
    let nHov = true;
    function checa(b) { if (clicou(pos, b)) { setBotaoHover(b.id); nHov = false; } }

    if (estadoJogo === "MENU") { checa(botaoStart); checa(botaoTutorial); checa(botaoConfig); }
    else if (estadoJogo === "SELECAO_FASES") { botoesFases.forEach(checa); checa(botaoVoltar); }
    else if (estadoJogo === "PAUSA") { checa(botaoRetomar); checa(botaoVoltarFases); checa(botaoVoltarMenu); }
    else if (estadoJogo === "JOGANDO") checa(botaoPausaHUD);
    else if (estadoJogo === "TUTORIAL") checa(botaoVoltar);
    else if (estadoJogo === "CONFIG") { checa(btnMusicaMenos); checa(btnMusicaMais); checa(btnEfeitosMenos); checa(btnEfeitosMais); checa(botaoVoltar); }

    if (nHov) setBotaoHover(null); 

    if (estadoJogo === "JOGANDO" && arrastando && lixoSelecionado) {
        if (evento.cancelable) evento.preventDefault();
        lixoSelecionado.x = pos.x - (8 * jogoScale);
        lixoSelecionado.y = pos.y - (8 * jogoScale);
    }
}

function aoFinalizarToque() {
    if (estadoJogo !== "JOGANDO" || !lixoSelecionado) return;
    
    let lixeiraAlvo = null;
    let lAtual = lixoSelecionado; 
    
    for (let lix of lixeirasAtivas) {
        if (lAtual.x + (8 * jogoScale) > lix.x && lAtual.x + (8 * jogoScale) < lix.x + lix.largura &&
            lAtual.y + (8 * jogoScale) > lix.y && lAtual.y + (8 * jogoScale) < lix.y + lix.altura) {
            lixeiraAlvo = lix; break;
        }
    }

    setLixoSelecionado(null); setArrastando(false);

    if (lixeiraAlvo) {
        window.dispatchEvent(new CustomEvent("lixoSoltoNaLixeira", { detail: { lixo: lAtual, lixeira: lixeiraAlvo } }));
    } else {
        let linhaM = posicoesLinhas[0], menorD = Infinity;
        for (let Y of posicoesLinhas) {
            let d = Math.abs(lAtual.y - Y);
            if (d < menorD) { menorD = d; linhaM = Y; }
        }
        lAtual.y = linhaM;
    }
}

canvas.addEventListener("mousedown", aoIniciarToque);
window.addEventListener("mousemove", aoMovimentarMouseHUD, { passive: false });
window.addEventListener("mouseup", aoFinalizarToque);
window.addEventListener("mouseleave", aoFinalizarToque); 

canvas.addEventListener("touchstart", aoIniciarToque, { passive: false });
canvas.addEventListener("touchmove", aoMovimentarMouseHUD, { passive: false });
window.addEventListener("touchend", aoFinalizarToque);
window.addEventListener("touchcancel", aoFinalizarToque);
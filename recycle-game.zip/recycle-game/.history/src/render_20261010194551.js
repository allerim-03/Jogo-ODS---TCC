// ==========================================
// RENDERIZADORES DE TELAS E INTERFACE
// ==========================================

import { 
    canvas, ctx, estadoJogo, faseAtual, pontos, vidas, fasesDesbloqueadas,
    lixeirasAtivas, listaLixos, lixosColetados, metasColeta, totalLixosNecessarios,
    jogoScale, NUM_LINHAS, esteiraY, botoesFases, botaoPausaHUD, 
    botaoRetomar, botaoVoltarFases, botaoVoltarMenu, botaoHover, lixoSelecionado,
    botaoStart, botaoTutorial, botaoConfig, botaoVoltar, btnMusicaMenos, btnMusicaMais, 
    btnEfeitosMenos, btnEfeitosMais, volumeMusica, volumeEfeitos, tutorialEstado,
    imgCenario 
} from './config.js';

import { matrizRachaduras } from './art.js';

// Desenho da Avaliação do Funcionário (Estrela)
const matrizEstrela = [
    "....KK....", "...KYYK...", "..KYYYYK..", ".KYYYYYYK.", "KKYYYYYYKK",
    ".KYYYYYYK.", "..KYYYYK..", ".KYYKKYYK.", "KYYK..KYYK", "KKK....KKK"
];

function desenharFundoBase() {
    ctx.fillStyle = "#334155"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    let pr = [ {x: 50, y: 350}, {x: 700, y: 50}, {x: 500, y: 400}, {x: 100, y: 70} ];
    for (let p of pr) {
        for (let y = 0; y < matrizRachaduras.length; y++) {
            for (let x = 0; x < matrizRachaduras[y].length; x++) {
                if (matrizRachaduras[y][x] === 'D') {
                    ctx.fillStyle = "#1E293B"; ctx.fillRect(p.x + (x * jogoScale), p.y + (y * jogoScale), jogoScale, jogoScale);
                }
            }
        }
    }
}

function desenharEsteiraHorizontal(timestamp) {
    const alt = (NUM_LINHAS * 16) + ((NUM_LINHAS - 1) * 3) + 6;
    ctx.fillStyle = "#111827"; ctx.fillRect(0, esteiraY, canvas.width, alt * jogoScale);
    let off = (timestamp / 20) % (16 * jogoScale); 

    // Se a esteira estiver congelada no tutorial, paralisa a animação visual
    if (estadoJogo === "TUTORIAL" && tutorialEstado > 0) off = 0;

    for (let i = 0; i < NUM_LINHAS; i++) {
        let fy = esteiraY + (i * 19 * jogoScale) + (3 * jogoScale);
        ctx.fillStyle = "#4B5563"; ctx.fillRect(0, fy, canvas.width, 16 * jogoScale);
        ctx.fillStyle = "#374151";
        for (let x = -300; x < canvas.width; x += 16 * jogoScale) ctx.fillRect(x + off, fy, 2 * jogoScale, 16 * jogoScale);
        if (i < NUM_LINHAS - 1) { ctx.fillStyle = "#1F2937"; ctx.fillRect(0, fy + (16 * jogoScale), canvas.width, 3 * jogoScale); }
    }
    let lb = 8 * jogoScale;
    for (let x = 0; x < canvas.width; x += lb) {
        ctx.fillStyle = (Math.floor(x / lb) % 2 === 0) ? "#EAB308" : "#151518";
        ctx.fillRect(x, esteiraY, lb, 3 * jogoScale); 
        ctx.fillRect(x, esteiraY + (alt * jogoScale) - (3 * jogoScale), lb, 3 * jogoScale); 
    }
}

export function desenharBotaoPixelArt(texto, b, corBase, corTexto = "#FFFFFF") {
    let hover = (botaoHover === b.id);
    ctx.fillStyle = hover ? "#FFFFFF" : corBase; ctx.fillRect(b.x, b.y, b.largura, b.altura);
    if (hover) { ctx.fillStyle = "rgba(255, 255, 255, 0.2)"; ctx.fillRect(b.x, b.y, b.largura, b.altura); }

    const esp = 4;
    ctx.fillStyle = "#151518"; // Borda
    ctx.fillRect(b.x, b.y, b.largura, esp); ctx.fillRect(b.x, b.y + b.altura - esp, b.largura, esp); 
    ctx.fillRect(b.x, b.y, esp, b.altura); ctx.fillRect(b.x + b.largura - esp, b.y, esp, b.altura); 

    ctx.fillStyle = "#FFFFFF"; // Luz
    ctx.fillRect(b.x + esp, b.y + esp, b.largura - (esp * 2), esp);
    ctx.fillRect(b.x + esp, b.y + esp, esp, b.altura - (esp * 2));

    ctx.fillStyle = "rgba(0, 0, 0, 0.3)"; // Sombra
    ctx.fillRect(b.x + esp, b.y + b.altura - (esp * 2), b.largura - (esp * 2), esp);
    ctx.fillRect(b.x + b.largura - (esp * 2), b.y + esp, esp, b.altura - (esp * 2));

    ctx.fillStyle = corTexto;
    ctx.font = b.largura > 100 ? "bold 18px 'Segoe UI'" : "bold 24px 'Segoe UI'"; 
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(texto, b.x + (b.largura / 2), b.y + (b.altura / 2) + 2);
}

export function desenharPartida(timestamp) {
    desenharFundoBase(); desenharEsteiraHorizontal(timestamp);

    for (let l of lixeirasAtivas) {
        if (l.spriteInfo.imagem && l.spriteInfo.imagem.isReady) ctx.drawImage(l.spriteInfo.imagem, l.x, l.y, l.largura, l.altura);
        else { ctx.fillStyle = l.spriteInfo.cor; ctx.fillRect(l.x, l.y, l.largura, l.altura); }
        ctx.fillStyle = "#E2E8F0"; ctx.font = "bold 14px 'Segoe UI'"; ctx.textAlign = "center";
        ctx.fillText(l.nome, l.x + (l.largura / 2), l.y + l.altura + 20);
    }

    for (let l of listaLixos) {
        let tamFinal = (16 * jogoScale) + (l === lixoSelecionado ? 8 : 0);
        let dx = l.x - (l === lixoSelecionado ? 4 : 0), dy = l.y - (l === lixoSelecionado ? 4 : 0);
        if (l.imagemLixo && l.imagemLixo.isReady) ctx.drawImage(l.imagemLixo, dx, dy, tamFinal, tamFinal);
        else { ctx.fillStyle = l.sprite.cor; ctx.fillRect(dx, dy, tamFinal, tamFinal); }
    }

    // HUD Superior Corporativa
    ctx.fillStyle = "rgba(15, 23, 42, 0.95)"; ctx.fillRect(0, 0, canvas.width, 70);

    let sX = 20;
    for (let v = 0; v < 3; v++) { // Sempre desenha 3 espaços de avaliação
        let hX = sX + (v * 12 * 3); 
        let cheia = v < vidas; // Se tem advertência, a estrela fica cinza
        for (let y = 0; y < matrizEstrela.length; y++) {
            for (let x = 0; x < matrizEstrela[y].length; x++) {
                let c = matrizEstrela[y][x];
                if (c === 'K') { ctx.fillStyle = '#000000'; ctx.fillRect(hX + x*3, 20 + y*3, 3, 3); }
                else if (c === 'Y') { ctx.fillStyle = cheia ? '#FBBF24' : '#475569'; ctx.fillRect(hX + x*3, 20 + y*3, 3, 3); }
            }
        }
    }

    // Salário (Pontos)
    ctx.fillStyle = "#10B981"; ctx.font = "bold 24px 'Courier New', monospace"; ctx.textAlign = "right";
    ctx.fillText(`R$ ${String(pontos).padStart(4, '0')},00`, canvas.width - 20, 32);

    // Botão Pausar / Almoço
    if (estadoJogo === "JOGANDO") {
        ctx.fillStyle = "#334155"; ctx.fillRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
        ctx.strokeStyle = botaoHover === "PAUSA" ? "#FFFFFF" : "#0f172a"; ctx.strokeRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
        ctx.fillStyle = "#F1F5F9"; ctx.font = "bold 12px 'Segoe UI'"; ctx.textAlign = "center";
        ctx.fillText("PAUSA ||", botaoPausaHUD.x + (botaoPausaHUD.largura / 2), botaoPausaHUD.y + 17);
    }

    // Progresso do Turno
    if (faseAtual < 5) {
        ctx.fillStyle = "#475569"; ctx.fillRect(0, 70, canvas.width, 8);
        let val = 0;
        for (let l of lixeirasAtivas) val += Math.min(lixosColetados[l.cor] || 0, metasColeta[l.cor]);
        ctx.fillStyle = "#388E3C"; ctx.fillRect(0, 70, canvas.width * Math.min(1, Math.max(0, val / totalLixosNecessarios)), 8);

        let esp = 90, stX = (canvas.width / 2) - ((lixeirasAtivas.length * esp) / 2) + (esp/2);
        for (let k = 0; k < lixeirasAtivas.length; k++) {
            let lix = lixeirasAtivas[k], atual = lixosColetados[lix.cor] || 0, meta = metasColeta[lix.cor];
            let bx = stX + (k * esp) - 40;
            ctx.fillStyle = lix.spriteInfo.cor; ctx.fillRect(bx, 48, 14, 14);
            ctx.strokeStyle = "#000"; ctx.strokeRect(bx, 48, 14, 14);
            ctx.fillStyle = (atual >= meta) ? "#10B981" : "#E2E8F0";
            ctx.font = "bold 14px 'Courier New'"; ctx.textAlign = "left"; ctx.fillText(`${atual}/${meta}`, bx + 20, 60);
        }
    } else {
        ctx.fillStyle = "#A855F7"; ctx.font = "bold 14px 'Segoe UI'"; ctx.textAlign = "center";
        ctx.fillText("⚡ HORA EXTRA (SEM FIM) ⚡", canvas.width / 2, 60);
    }
}

export function desenharTutorialInterativo(timestamp) {
    desenharPartida(timestamp); 
    
    if (tutorialEstado === 1) {
        ctx.fillStyle = "rgba(15, 23, 42, 0.4)"; ctx.fillRect(0, 78, canvas.width, canvas.height); // Véu escuro

        if (Math.floor(timestamp / 500) % 2 === 0) {
            ctx.fillStyle = "#FBBF24"; ctx.font = "bold 26px 'Segoe UI'"; ctx.textAlign = "center";
            ctx.fillText("INTEGRAÇÃO - DIA 1", canvas.width / 2, 140);
            ctx.fillStyle = "#FFFFFF"; ctx.font = "18px 'Segoe UI'";
            ctx.fillText("Segure o lixo e arraste para a lixeira correta", canvas.width / 2, 170);
        }
        
        // Desenho da Seta piscante
        let l = listaLixos[0], lix = lixeirasAtivas[0];
        if (l && lix) {
            let osc = Math.sin(timestamp / 150) * 10;
            let x1 = l.x + 30, y1 = l.y + 60 + osc, x2 = lix.x + 40, y2 = lix.y - 15 + osc;
            
            ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
            ctx.strokeStyle = "#FBBF24"; ctx.lineWidth = 4; ctx.setLineDash([10, 10]);
            ctx.stroke(); ctx.setLineDash([]);
            
            ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - 15, y2 - 15); ctx.lineTo(x2 + 10, y2 - 20);
            ctx.fillStyle = "#FBBF24"; ctx.fill();
        }
    } else if (tutorialEstado === 2) {
        ctx.fillStyle = "rgba(16, 185, 129, 0.9)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#FFFFFF"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center";
        ctx.fillText("VOCÊ FOI CONTRATADO! 🎉", canvas.width / 2, canvas.height / 2);
        ctx.font = "20px 'Segoe UI'"; ctx.fillText("O turno vai começar...", canvas.width / 2, canvas.height / 2 + 40);
    }
}

function desenharModalCaixa(titulo, subTitulo, corTitulo) {
    ctx.fillStyle = "rgba(15, 23, 42, 0.75)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    let bw = 560, bh = 220, bx = (canvas.width / 2) - (bw / 2), by = (canvas.height / 2) - (bh / 2);
    
    ctx.fillStyle = "#1E293B"; ctx.fillRect(bx, by, bw, bh);
    ctx.strokeStyle = corTitulo; ctx.lineWidth = 4; ctx.strokeRect(bx, by, bw, bh);

    ctx.fillStyle = corTitulo; ctx.font = "bold 32px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText(titulo, canvas.width / 2, by + 60);
    ctx.fillStyle = "#CBD5E1"; ctx.font = "18px 'Segoe UI'"; ctx.fillText(subTitulo, canvas.width / 2, by + 110);
    ctx.fillStyle = "#64748B"; ctx.font = "14px 'Segoe UI'"; ctx.fillText("Clique em qualquer lugar para continuar", canvas.width / 2, by + 180);
}

export function desenharMenu() {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.7)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#10B981"; ctx.font = "bold 48px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("RECICLACOOP", canvas.width / 2, 130);
    ctx.font = "20px 'Segoe UI'"; ctx.fillStyle = "#94A3B8";
    ctx.fillText("Bem-vindo ao seu primeiro dia! Bata o ponto para iniciar o expediente.", canvas.width / 2, 175);
    
    desenharBotaoPixelArt("BATER PONTO", botaoStart, "#059669");
    desenharBotaoPixelArt("TUTORIAL", botaoTutorial, "#475569", "#CBD5E1");
    desenharBotaoPixelArt("CONFIG.", botaoConfig, "#475569", "#CBD5E1");
}

export function desenharSelecaoFases() {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.8)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#ffffff"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("Quadro de Escalas", canvas.width / 2, 80);
    ctx.fillStyle = "#94A3B8"; ctx.font = "16px 'Segoe UI'";
    ctx.fillText("Selecione o seu setor de trabalho", canvas.width / 2, 110);
    
    for (let b of botoesFases) {
        let lib = fasesDesbloqueadas[b.fase];
        desenharBotaoPixelArt(b.fase === 5 ? "∞" : "S" + b.fase, b, lib ? b.cor : "#475569");
        if (!lib) { ctx.fillStyle = "#FFFFFF"; ctx.font = "20px Arial"; ctx.fillText("🔒", b.x + (b.largura / 2), b.y + b.altura + 25); }
    }
    desenharBotaoPixelArt("VOLTAR", botaoVoltar, "#64748B");
}

export function desenharConfig() {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.9)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#10B981"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center"; ctx.fillText("CONFIGURAÇÕES", canvas.width / 2, 80);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'Segoe UI'"; ctx.fillText("Música", canvas.width / 2, 150);
    desenharBotaoPixelArt("-", btnMusicaMenos, "#475569"); desenharBotaoPixelArt("+", btnMusicaMais, "#475569");
    ctx.font = "bold 24px 'Segoe UI'"; ctx.fillText(volumeMusica + "%", canvas.width / 2, 198);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'Segoe UI'"; ctx.fillText("Efeitos", canvas.width / 2, 240);
    desenharBotaoPixelArt("-", btnEfeitosMenos, "#475569"); desenharBotaoPixelArt("+", btnEfeitosMais, "#475569");
    ctx.font = "bold 24px 'Segoe UI'"; ctx.fillText(volumeEfeitos + "%", canvas.width / 2, 288);
    desenharBotaoPixelArt("SALVAR", botaoVoltar, "#059669");
}

export function desenharVitoria(timestamp) {
    desenharPartida(timestamp); 
    desenharModalCaixa("FIM DO EXPEDIENTE! 🏭", "Meta batida. O supervisor está orgulhoso do seu trabalho!", "#10B981");
}

export function desenharGameOver(timestamp) {
    desenharPartida(timestamp);
    let sub = (faseAtual === 5) ? `Fim da Hora Extra. Você acumulou R$ ${pontos},00.` : `Advertências esgotadas! Desconto no salário: R$ ${pontos},00.`;
    desenharModalCaixa(faseAtual === 5 ? "Turno Encerrado!" : "LENTO DEMAIS! 🚫", sub, faseAtual === 5 ? "#3B82F6" : "#EF4444");
}

export function desenharMenuPausa(timestamp) {
    desenharPartida(timestamp);
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#FFFFFF"; ctx.font = "bold 40px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("HORÁRIO DE ALMOÇO (PAUSADO)", canvas.width / 2, 120);
    
    desenharBotaoPixelArt("VOLTAR À ESTEIRA", botaoRetomar, "#059669");
    desenharBotaoPixelArt("TROCAR DE SETOR", botaoVoltarFases, "#2563EB");
    desenharBotaoPixelArt("BATER PONTO (MENU)", botaoVoltarMenu, "#DC2626");
}
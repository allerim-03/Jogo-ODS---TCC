// ==========================================
// RENDERIZADORES DE TELAS E INTERFACE (UI)
// ==========================================

import { 
    canvas, ctx, estadoJogo, faseAtual, pontos, vidas, fasesDesbloqueadas,
    lixeirasAtivas, listaLixos, lixosColetados, metasColeta, totalLixosNecessarios,
    jogoScale, NUM_LINHAS, esteiraY, botoesFases, botaoPausaHUD, 
    botaoRetomar, botaoVoltarFases, botaoVoltarMenu, botaoHover, lixoSelecionado,
    botaoStart, botaoTutorial, botaoConfig, botaoVoltar, // <-- NOVOS
    btnMusicaMenos, btnMusicaMais, btnEfeitosMenos, btnEfeitosMais, // <-- NOVOS
    volumeMusica, volumeEfeitos // <-- NOVOS
} from './config.js';

import { 
    matrizCoracao, paletaComumLixeiras, matrizRachaduras 
} from './art.js';

export function desenharFundoBase() {
    ctx.fillStyle = "#334155";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    let posRachaduras = [ {x: 50, y: 350}, {x: 700, y: 50}, {x: 500, y: 400}, {x: 100, y: 70} ];
    for (let p of posRachaduras) {
        for (let y = 0; y < matrizRachaduras.length; y++) {
            for (let x = 0; x < matrizRachaduras[y].length; x++) {
                let c = matrizRachaduras[y][x];
                if (c === 'D') {
                    ctx.fillStyle = "#1E293B";
                    ctx.fillRect(p.x + (x * jogoScale), p.y + (y * jogoScale), jogoScale, jogoScale);
                }
            }
        }
    }
}

function desenharEsteiraHorizontal(timestamp) {
    const alturaEsteiraPixels = (NUM_LINHAS * 16) + ((NUM_LINHAS - 1) * 3) + 6;
    const alturaEsteiraEscalada = alturaEsteiraPixels * jogoScale; 

    ctx.fillStyle = "#111827";
    ctx.fillRect(0, esteiraY, canvas.width, alturaEsteiraEscalada);

    let offsetAnima = (timestamp / 20) % (16 * jogoScale); 

    for (let i = 0; i < NUM_LINHAS; i++) {
        let faixaY = esteiraY + (i * 19 * jogoScale) + (3 * jogoScale);
        
        ctx.fillStyle = "#4B5563";
        ctx.fillRect(0, faixaY, canvas.width, 16 * jogoScale);

        ctx.fillStyle = "#374151";
        for (let x = -300; x < canvas.width; x += 16 * jogoScale) {
            ctx.fillRect(x + offsetAnima, faixaY, 2 * jogoScale, 16 * jogoScale);
        }

        if (i < NUM_LINHAS - 1) {
            ctx.fillStyle = "#1F2937";
            ctx.fillRect(0, faixaY + (16 * jogoScale), canvas.width, 3 * jogoScale);
        }
    }

    let largBloco = 8 * jogoScale;
    for (let x = 0; x < canvas.width; x += largBloco) {
        ctx.fillStyle = (Math.floor(x / largBloco) % 2 === 0) ? "#EAB308" : "#151518";
        ctx.fillRect(x, esteiraY, largBloco, 3 * jogoScale); 
        ctx.fillRect(x, esteiraY + alturaEsteiraEscalada - (3 * jogoScale), largBloco, 3 * jogoScale); 
    }
}

export function desenharBotaoPixelArt(texto, b, corBase, corTexto = "#FFFFFF") {
    let estado = (botaoHover === b.id) ? "hover" : "normal";
    const K = "#151518", L = "#FFFFFF", S = "rgba(0, 0, 0, 0.3)";
    
    let corCorpo = corBase;
    if (estado === "hover") {
        ctx.fillStyle = corBase;
        ctx.fillStyle = "#FFFFFF";
    }

    ctx.fillStyle = corCorpo;
    ctx.fillRect(b.x, b.y, b.largura, b.altura);
    if (estado === "hover") {
        ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
        ctx.fillRect(b.x, b.y, b.largura, b.altura);
    }

    const esp = 4;
    ctx.fillStyle = K;
    ctx.fillRect(b.x, b.y, b.largura, esp); 
    ctx.fillRect(b.x, b.y + b.altura - esp, b.largura, esp); 
    ctx.fillRect(b.x, b.y, esp, b.altura); 
    ctx.fillRect(b.x + b.largura - esp, b.y, esp, b.altura); 

    ctx.fillStyle = L;
    ctx.fillRect(b.x + esp, b.y + esp, b.largura - (esp * 2), esp);
    ctx.fillRect(b.x + esp, b.y + esp, esp, b.altura - (esp * 2));

    ctx.fillStyle = S;
    ctx.fillRect(b.x + esp, b.y + b.altura - (esp * 2), b.largura - (esp * 2), esp);
    ctx.fillRect(b.x + b.largura - (esp * 2), b.y + esp, esp, b.altura - (esp * 2));

    ctx.fillStyle = corTexto;
    ctx.font = b.largura > 100 ? "bold 18px 'Segoe UI'" : "bold 24px 'Segoe UI'"; 
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(texto, b.x + (b.largura / 2), b.y + (b.altura / 2) + 2);
}

export function desenharPartida(timestamp) {
    desenharFundoBase();
    desenharEsteiraHorizontal(timestamp);

    // Lixeiras Ativas (Usando Imagens)
    for (let l of lixeirasAtivas) {
        // Usa a trava 'isReady' que nós mesmos criamos no config.js
        if (l.spriteInfo.imagem && l.spriteInfo.imagem.isReady) {
            ctx.drawImage(l.spriteInfo.imagem, l.x, l.y, l.largura, l.altura);
        } else {
            // Se a imagem falhar, desenha o quadrado colorido sólido para o jogo não travar
            ctx.fillStyle = l.spriteInfo.cor;
            ctx.fillRect(l.x, l.y, l.largura, l.altura);
        }
        
        ctx.fillStyle = "#E2E8F0";
        ctx.font = "bold 14px 'Segoe UI'";
        ctx.textAlign = "center";
        ctx.fillText(l.nome, l.x + (l.largura / 2), l.y + l.altura + 20);
    }

    // Lixos em Movimento
    for (let l of listaLixos) {
        let tamanhoBase = 16 * jogoScale; // 64 pixels (tamanho original escalado)
        let aumentoAoSegurar = (l === lixoSelecionado) ? 8 : 0; 
        let tamanhoFinal = tamanhoBase + aumentoAoSegurar;
        
        let drawX = l.x - (aumentoAoSegurar / 2);
        let drawY = l.y - (aumentoAoSegurar / 2);

        if (l.imagemLixo && l.imagemLixo.isReady) {
            ctx.drawImage(l.imagemLixo, drawX, drawY, tamanhoFinal, tamanhoFinal);
        } else {
            // Quadrado colorido de proteção caso a imagem quebre
            ctx.fillStyle = l.sprite.cor;
            ctx.fillRect(drawX, drawY, tamanhoFinal, tamanhoFinal);
        }
    }

    // Interface HUD
    ctx.fillStyle = "rgba(15, 23, 42, 0.95)";
    ctx.fillRect(0, 0, canvas.width, 70);

    let startHeartX = 20;
    for (let v = 0; v < vidas; v++) {
        let hX = startHeartX + (v * 13 * 3); 
        for (let y = 0; y < matrizCoracao.length; y++) {
            for (let x = 0; x < matrizCoracao[y].length; x++) {
                let c = matrizCoracao[y][x];
                if (c === 'K') { ctx.fillStyle = '#000000'; ctx.fillRect(hX + x*3, 15 + y*3, 3, 3); }
                else if (c === 'R') { ctx.fillStyle = '#EF4444'; ctx.fillRect(hX + x*3, 15 + y*3, 3, 3); }
            }
        }
    }

    ctx.fillStyle = "#10B981";
    ctx.font = "bold 24px 'Courier New', monospace";
    ctx.textAlign = "right";
    let ptsFmt = String(pontos).padStart(5, '0');
    ctx.fillText(`${ptsFmt} PTS`, canvas.width - 20, 32);

    ctx.fillStyle = "#334155";
    ctx.fillRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
    ctx.strokeStyle = botaoHover === "PAUSA" ? "#FFFFFF" : "#0f172a";
    ctx.strokeRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
    ctx.fillStyle = "#F1F5F9";
    ctx.font = "bold 12px 'Segoe UI'";
    ctx.textAlign = "center";
    ctx.fillText("PAUSA ||", botaoPausaHUD.x + (botaoPausaHUD.largura / 2), botaoPausaHUD.y + 17);

    // Barra de Progresso e Metas (Para fases 1 a 4)
    if (faseAtual < 5) {
        ctx.fillStyle = "#475569";
        ctx.fillRect(0, 70, canvas.width, 8);
        
        let valColetados = 0;
        for (let l of lixeirasAtivas) {
            let k = l.cor.toLowerCase();
            valColetados += Math.min(lixosColetados[k] || 0, metasColeta[k]);
        }
        let percent = Math.min(1, Math.max(0, valColetados / totalLixosNecessarios));
        ctx.fillStyle = "#388E3C";
        ctx.fillRect(0, 70, canvas.width * percent, 8);

        let esp = 90; 
        let startX = (canvas.width / 2) - ((lixeirasAtivas.length * esp) / 2) + (esp/2);
        
        for (let k = 0; k < lixeirasAtivas.length; k++) {
            let lix = lixeirasAtivas[k];
            let cChave = lix.cor.toLowerCase();
            let atual = lixosColetados[cChave] || 0;
            let meta = metasColeta[cChave];
            
            let boxX = startX + (k * esp) - 40;
            ctx.fillStyle = lix.spriteInfo.cor;
            ctx.fillRect(boxX, 48, 14, 14);
            ctx.strokeStyle = "#000"; ctx.strokeRect(boxX, 48, 14, 14);
            
            ctx.fillStyle = (atual >= meta) ? "#10B981" : "#E2E8F0";
            ctx.font = "bold 14px 'Courier New'";
            ctx.textAlign = "left";
            ctx.fillText(`${atual}/${meta}`, boxX + 20, 60);
        }
    } else {
        ctx.fillStyle = "#A855F7"; ctx.font = "bold 14px 'Segoe UI'"; ctx.textAlign = "center";
        ctx.fillText("⚡ MODO SOBREVIVÊNCIA INFINITO ⚡", canvas.width / 2, 60);
    }
}

function desenharModalCaixa(titulo, subTitulo, corTitulo) {
    ctx.fillStyle = "rgba(15, 23, 42, 0.75)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    let boxW = 460, boxH = 220;
    let boxX = (canvas.width / 2) - (boxW / 2);
    let boxY = (canvas.height / 2) - (boxH / 2);

    ctx.fillStyle = "#1E293B";
    ctx.fillRect(boxX, boxY, boxW, boxH);
    ctx.strokeStyle = corTitulo;
    ctx.lineWidth = 4;
    ctx.strokeRect(boxX, boxY, boxW, boxH);

    ctx.fillStyle = corTitulo; 
    ctx.font = "bold 32px 'Segoe UI'"; 
    ctx.textAlign = "center";
    ctx.fillText(titulo, canvas.width / 2, boxY + 60);
    
    ctx.fillStyle = "#CBD5E1"; 
    ctx.font = "18px 'Segoe UI'";
    ctx.fillText(subTitulo, canvas.width / 2, boxY + 110);
    
    ctx.fillStyle = "#64748B"; 
    ctx.font = "14px 'Segoe UI'";
    ctx.fillText("Clique em qualquer lugar para continuar", canvas.width / 2, boxY + 180);
}

export function desenharMenu(timestamp) {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.7)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#10B981"; ctx.font = "bold 48px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("RECICLA HORIZON", canvas.width / 2, 140);
    ctx.font = "20px 'Segoe UI'"; ctx.fillStyle = "#94A3B8";
    ctx.fillText("Mantenha a fábrica limpa. Deslize o lixo para as lixeiras corretas!", canvas.width / 2, 190);
    
    desenharBotaoPixelArt("JOGAR", botaoStart, "#059669");
    // Botões menores desenhados com um cinza neutro
    desenharBotaoPixelArt("COMO JOGAR", botaoTutorial, "#475569", "#CBD5E1");
    desenharBotaoPixelArt("CONFIG.", botaoConfig, "#475569", "#CBD5E1");
}

export function desenharSelecaoFases(timestamp) {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.8)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#ffffff"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("Selecione o Turno", canvas.width / 2, 100);
    
    for (let b of botoesFases) {
        let liberada = fasesDesbloqueadas[b.fase];
        let cor = liberada ? b.cor : "#475569";
        desenharBotaoPixelArt(b.fase === 5 ? "∞" : String(b.fase), b, cor);
        if (!liberada) { 
            ctx.fillStyle = "#FFFFFF"; ctx.font = "20px Arial"; 
            ctx.fillText("🔒", b.x + (b.largura / 2), b.y + b.altura + 25); 
        }
    }
    
    desenharBotaoPixelArt("VOLTAR", botaoVoltar, "#64748B");
}

export function desenharTutorial(timestamp) {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.9)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#10B981"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("COMO JOGAR", canvas.width / 2, 80);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'Segoe UI'";
    ctx.fillText("1. Lixos surgirão na esteira da esquerda para a direita.", canvas.width / 2, 150);
    ctx.fillText("2. Arraste os lixos para as lixeiras correspondentes.", canvas.width / 2, 190);
    ctx.fillText("3. Se muitos lixos escaparem, você é demitido!", canvas.width / 2, 230);
    ctx.fillText("4. Atingindo a meta, você avança para o próximo turno.", canvas.width / 2, 270);

    desenharBotaoPixelArt("ENTENDI", botaoVoltar, "#059669");
}

export function desenharConfig(timestamp) {
    desenharFundoBase();
    ctx.fillStyle = "rgba(15, 23, 42, 0.9)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#10B981"; ctx.font = "bold 36px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("CONFIGURAÇÕES", canvas.width / 2, 80);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'Segoe UI'";
    ctx.fillText("Volume da Música", canvas.width / 2, 150);
    desenharBotaoPixelArt("-", btnMusicaMenos, "#475569");
    desenharBotaoPixelArt("+", btnMusicaMais, "#475569");
    ctx.font = "bold 24px 'Segoe UI'";
    ctx.fillText(volumeMusica + "%", canvas.width / 2, 198);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'Segoe UI'";
    ctx.fillText("Volume dos Efeitos", canvas.width / 2, 240);
    desenharBotaoPixelArt("-", btnEfeitosMenos, "#475569");
    desenharBotaoPixelArt("+", btnEfeitosMais, "#475569");
    ctx.font = "bold 24px 'Segoe UI'";
    ctx.fillText(volumeEfeitos + "%", canvas.width / 2, 288);

    desenharBotaoPixelArt("SALVAR", botaoVoltar, "#059669");
}

export function desenharVitoria(timestamp) {
    desenharPartida(timestamp); 
    desenharModalCaixa("Turno Concluído! 🎉", "Excelente trabalho! O meio ambiente agradece.", "#10B981");
}

export function desenharGameOver(timestamp) {
    desenharPartida(timestamp);
    let sub = (faseAtual === 5) ? `Fim do expediente. Você reciclou ${pontos} pontos!` : "Muitos resíduos passaram! Preste atenção.";
    desenharModalCaixa("Fim de Jogo!", sub, "#EF4444");
}

export function desenharMenuPausa(timestamp) {
    desenharPartida(timestamp);

    ctx.fillStyle = "rgba(15, 23, 42, 0.85)"; 
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#FFFFFF"; ctx.font = "bold 40px 'Segoe UI'"; ctx.textAlign = "center";
    ctx.fillText("EM ESPERA", canvas.width / 2, 120);
    
    desenharBotaoPixelArt("RETOMAR TRABALHO", botaoRetomar, "#059669");
    desenharBotaoPixelArt("TROCAR TURNO", botaoVoltarFases, "#2563EB");
    desenharBotaoPixelArt("BATER PONTO (SAIR)", botaoVoltarMenu, "#DC2626");
}
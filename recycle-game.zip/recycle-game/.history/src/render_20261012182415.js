// ==========================================
// RENDERIZADORES DE TELAS E INTERFACE
// ==========================================

import { 
    canvas, ctx, estadoJogo, faseAtual, pontos, vidas, fasesDesbloqueadas,
    lixeirasAtivas, listaLixos, lixosColetados, metasColeta, totalLixosNecessarios,
    jogoScale, NUM_LINHAS, esteiraY, botoesFases, botaoPausaHUD, 
    botaoRetomar, botaoVoltarFases, botaoVoltarMenu, botaoHover, lixoSelecionado,
    botaoStart, botaoTutorial, botaoConfig, botaoVoltar, btnMusicaMenos, btnMusicaMais, 
    btnEfeitosMenos, btnEfeitosMais, volumeMusica, volumeEfeitos, tutorialEstado,
    imgCenario, imgEsteira, mousePressionado, imgModalGrande, imgModalPequeno
} from './config.js';

// Desenho da Avaliação do Funcionário (Estrela)
const matrizEstrela = [
    "....KK....", "...KYYK...", "..KYYYYK..", ".KYYYYYYK.", "KKYYYYYYKK",
    ".KYYYYYYK.", "..KYYYYK..", ".KYYKKYYK.", "KYYK..KYYK", "KKK....KKK"
];

function desenharFundoBase() {
    // Verifica se a sua arte carregou perfeitamente
    if (imgCenario && imgCenario.isReady) {
        // Estampa a imagem começando do ponto X:0, Y:0 até preencher a largura e altura total
        ctx.drawImage(imgCenario, 0, 0, canvas.width, canvas.height);
    } else {
        // Tela cinza de proteção que pisca apenas se a imagem demorar a carregar
        ctx.fillStyle = "#334155"; 
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
}

function desenharEsteiraHorizontal(timestamp) {
    if (imgEsteira && imgEsteira.isReady) {
        // O código agora lê o tamanho real que você exportou!
        let larguraReal = imgEsteira.width;  
        let alturaReal = imgEsteira.height;

        let velocidade = 20; 
        let off = (timestamp / velocidade) % larguraReal;

        if (estadoJogo === "TUTORIAL" && tutorialEstado > 0) off = 0;

        // Repete o carimbo baseado na largura real da sua arte
        for (let x = -larguraReal; x < canvas.width; x += larguraReal) {
            ctx.drawImage(imgEsteira, x + off, esteiraY, larguraReal, alturaReal); 
        }
    } else {
        ctx.fillStyle = "#111827"; 
        ctx.fillRect(0, esteiraY, canvas.width, 250);
    }
}

export function desenharBotaoPixelArt(texto, b, corBase, corTexto = "#FFFFFF") {
    let hover = (botaoHover === b.id);
    let yDeslocamento = 0; // Controla se o botão vai afundar ao clicar

    // SE A SUA ARTE EXISTIR: Desenha a imagem vazia do botão
    if (b.imgNormal && b.imgNormal.isReady) {
        if (hover && mousePressionado && b.imgHover && b.imgHover.isReady) {
            yDeslocamento = 4; // Botão pressionado afunda 4 pixels
            ctx.drawImage(b.imgHover, b.x, b.y + yDeslocamento, b.largura, b.altura);
        } else if (hover && b.imgHover && b.imgHover.isReady) {
            ctx.drawImage(b.imgHover, b.x, b.y, b.largura, b.altura); // Mouse por cima
        } else {
            ctx.drawImage(b.imgNormal, b.x, b.y, b.largura, b.altura); // Normal
        }
    } 
    // FALLBACK DE SEGURANÇA: Se não achar a imagem, desenha o quadrado antigo colorido
    else {
        ctx.fillStyle = hover ? "#FFFFFF" : corBase; ctx.fillRect(b.x, b.y, b.largura, b.altura);
        if (hover) { ctx.fillStyle = "rgba(255, 255, 255, 0.2)"; ctx.fillRect(b.x, b.y, b.largura, b.altura); }

        const esp = 4;
        ctx.fillStyle = "#151518"; ctx.fillRect(b.x, b.y, b.largura, esp); ctx.fillRect(b.x, b.y + b.altura - esp, b.largura, esp); 
        ctx.fillRect(b.x, b.y, esp, b.altura); ctx.fillRect(b.x + b.largura - esp, b.y, esp, b.altura); 

        ctx.fillStyle = "#FFFFFF"; ctx.fillRect(b.x + esp, b.y + esp, b.largura - (esp * 2), esp); ctx.fillRect(b.x + esp, b.y + esp, esp, b.altura - (esp * 2));
        ctx.fillStyle = "rgba(0, 0, 0, 0.3)"; ctx.fillRect(b.x + esp, b.y + b.altura - (esp * 2), b.largura - (esp * 2), esp); ctx.fillRect(b.x + b.largura - (esp * 2), b.y + esp, esp, b.altura - (esp * 2));
        
        if (hover && mousePressionado) yDeslocamento = 2; // Efeito de apertar no modo fallback
    }

    // DESENHO DO TEXTO
    ctx.fillStyle = corTexto;
    ctx.font = b.largura > 100 ? "24px 'RiskOfRain'" : "18px 'RiskOfRain'"; 
    ctx.textAlign = "center"; 
    ctx.textBaseline = "middle";

    // Pega o ajuste individual do botão (se você não tiver colocado nenhum, ele usa 0 e não quebra o jogo)
    let ajusteX = b.ajusteTextoX || 0;
    let ajusteY = b.ajusteTextoY || 0;

    // Escreve o texto aplicando o seu ajuste individual!
    ctx.fillText(texto, b.x + (b.largura / 2) + ajusteX, b.y + (b.altura / 2) + 2 + yDeslocamento + ajusteY);
}

export function desenharPartida(timestamp) {
    desenharFundoBase(); desenharEsteiraHorizontal(timestamp);

    for (let l of lixeirasAtivas) {
        if (l.spriteInfo.imagem && l.spriteInfo.imagem.isReady) ctx.drawImage(l.spriteInfo.imagem, l.x, l.y, l.largura, l.altura);
        else { ctx.fillStyle = l.spriteInfo.cor; ctx.fillRect(l.x, l.y, l.largura, l.altura); }
        ctx.fillStyle = "#E2E8F0"; ctx.font = "bold 14px 'RiskOfRain'"; ctx.textAlign = "center";
        ctx.fillText(l.nome, l.x + (l.largura / 2), l.y + l.altura + 20);
    }

    for (let l of listaLixos) {
        let tamFinal = (16 * jogoScale) + (l === lixoSelecionado ? 8 : 0);
        let dx = l.x - (l === lixoSelecionado ? 4 : 0), dy = l.y - (l === lixoSelecionado ? 4 : 0);
        if (l.imagemLixo && l.imagemLixo.isReady) ctx.drawImage(l.imagemLixo, dx, dy, tamFinal, tamFinal);
        else { ctx.fillStyle = l.sprite.cor; ctx.fillRect(dx, dy, tamFinal, tamFinal); }
    }

    // HUD Superior Corporativa - Altura reduzida para 60
    ctx.fillStyle = "rgba(15, 23, 42, 0.95)"; ctx.fillRect(0, 0, canvas.width, 60);

    // Estrelas (Avaliação) - Subimos o Y de 20 para 15
    let sX = 20;
    for (let v = 0; v < 3; v++) { 
        let hX = sX + (v * 12 * 3); 
        let cheia = v < vidas; 
        for (let y = 0; y < matrizEstrela.length; y++) {
            for (let x = 0; x < matrizEstrela[y].length; x++) {
                let c = matrizEstrela[y][x];
                if (c === 'K') { ctx.fillStyle = '#000000'; ctx.fillRect(hX + x*3, 15 + y*3, 3, 3); }
                else if (c === 'Y') { ctx.fillStyle = cheia ? '#FBBF24' : '#475569'; ctx.fillRect(hX + x*3, 15 + y*3, 3, 3); }
            }
        }
    }

    // Salário (Pontos) - Centralizado no novo HUD
    ctx.fillStyle = "#10B981"; ctx.font = "bold 24px 'RiskOfRain', monospace"; ctx.textAlign = "right";
    ctx.fillText(`R$ ${String(pontos).padStart(4, '0')},00`, canvas.width - 20, 36);

    // Botão Pausar / Almoço (Usa a nova posição y=10 que colocamos no config)
    if (estadoJogo === "JOGANDO") {
        ctx.fillStyle = "#334155"; ctx.fillRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
        ctx.strokeStyle = botaoHover === "PAUSA" ? "#FFFFFF" : "#0f172a"; ctx.strokeRect(botaoPausaHUD.x, botaoPausaHUD.y, botaoPausaHUD.largura, botaoPausaHUD.altura);
        ctx.fillStyle = "#F1F5F9"; ctx.font = "bold 12px 'RiskOfRain'"; ctx.textAlign = "center";
        ctx.fillText("PAUSA ||", botaoPausaHUD.x + (botaoPausaHUD.largura / 2), botaoPausaHUD.y + 17);
    }

    // Progresso do Turno - Barra sobe para 60, ícones sobem para 40
    if (faseAtual < 5) {
        ctx.fillStyle = "#475569"; ctx.fillRect(0, 60, canvas.width, 8);
        let val = 0;
        for (let l of lixeirasAtivas) val += Math.min(lixosColetados[l.cor] || 0, metasColeta[l.cor]);
        ctx.fillStyle = "#388E3C"; ctx.fillRect(0, 60, canvas.width * Math.min(1, Math.max(0, val / totalLixosNecessarios)), 8);

        let esp = 90, stX = (canvas.width / 2) - ((lixeirasAtivas.length * esp) / 2) + (esp/2);
        for (let k = 0; k < lixeirasAtivas.length; k++) {
            let lix = lixeirasAtivas[k], atual = lixosColetados[lix.cor] || 0, meta = metasColeta[lix.cor];
            let bx = stX + (k * esp) - 40;
            ctx.fillStyle = lix.spriteInfo.cor; ctx.fillRect(bx, 40, 14, 14);
            ctx.strokeStyle = "#000"; ctx.strokeRect(bx, 40, 14, 14);
            ctx.fillStyle = (atual >= meta) ? "#10B981" : "#E2E8F0";
            ctx.font = "bold 14px 'RiskOfRain'"; ctx.textAlign = "left"; 
            ctx.fillText(`${atual}/${meta}`, bx + 20, 52);
        }
    } else {
        ctx.fillStyle = "#A855F7"; ctx.font = "bold 14px 'RiskOfRain'"; ctx.textAlign = "center";
        ctx.fillText("⚡ HORA EXTRA (SEM FIM) ⚡", canvas.width / 2, 45);
    }
}

export function desenharTutorialInterativo(timestamp) {
    desenharPartida(timestamp); 
    
    if (tutorialEstado === 1) {
        ctx.fillStyle = "rgba(15, 23, 42, 0.4)"; ctx.fillRect(0, 78, canvas.width, canvas.height); // Véu escuro

        if (Math.floor(timestamp / 500) % 2 === 0) {
            ctx.fillStyle = "#FBBF24"; ctx.font = "bold 26px 'RiskOfRain'"; ctx.textAlign = "center";
            ctx.fillText("INTEGRAÇÃO - DIA 1", canvas.width / 2, 140);
            ctx.fillStyle = "#FFFFFF"; ctx.font = "18px 'RiskOfRain'";
            ctx.fillText("Segure o lixo e arraste para a lixeira correta", canvas.width / 2, 170);
        }
        
        // Desenho da Seta piscante
        let l = listaLixos[0], lix = lixeirasAtivas[0];
        if (l && lix) {
            let osc = Math.sin(timestamp / 150) * 10;
            let x1 = l.x + 30, y1 = l.y + 60 + osc, x2 = lix.x + 40, y2 = lix.y - 15 + osc;
            
            ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
            ctx.strokeStyle = "#FBBF24"; ctx.lineWidth = 4; ctx.setLineDash([10, 10]);
            ctx.stroke(); ctx.setLineDash([]);
            
            ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - 15, y2 - 15); ctx.lineTo(x2 + 10, y2 - 20);
            ctx.fillStyle = "#FBBF24"; ctx.fill();
        }
    } else if (tutorialEstado === 2) {
        ctx.fillStyle = "rgba(16, 185, 129, 0.9)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#FFFFFF"; ctx.font = "bold 36px 'RiskOfRain'"; ctx.textAlign = "center";
        ctx.fillText("VOCÊ FOI CONTRATADO! 🎉", canvas.width / 2, canvas.height / 2);
        ctx.font = "20px 'RiskOfRain'"; ctx.fillText("O turno vai começar...", canvas.width / 2, canvas.height / 2 + 40);
    }
}

function desenharModalCaixa(titulo, subTitulo, corTitulo) {
    ctx.fillStyle = "rgba(15, 23, 42, 0.75)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    let bw = 560, bh = 220; // Tamanho ideal do modal pequeno
    let bx = (canvas.width / 2) - (bw / 2);
    let by = (canvas.height / 2) - (bh / 2);
    
    // Desenha a sua arte do Modal Pequeno!
    if (imgModalPequeno && imgModalPequeno.isReady) {
        ctx.drawImage(imgModalPequeno, bx, by, bw, bh);
    } else {
        // Fallback escuro caso a imagem demore a carregar
        ctx.fillStyle = "#1E293B"; ctx.fillRect(bx, by, bw, bh);
    }

    // Textos já com a sua fonte Risk of Rain ajustada70
    ctx.fillStyle = corTitulo; ctx.font = "36px 'RiskOfRain'"; ctx.textAlign = "center";
    ctx.fillText(titulo, canvas.width / 2, by + 70);
    
    ctx.fillStyle = "#CBD5E1"; ctx.font = "20px 'RiskOfRain'"; 
    ctx.fillText(subTitulo, canvas.width / 2, by + 110);
    
    ctx.fillStyle = "#64748B"; ctx.font = "16px 'RiskOfRain'"; 
    ctx.fillText("Clique em qualquer lugar para continuar", canvas.width / 2, by + 180);
}

export function desenharMenu() {
    desenharFundoBase();
    
    // Véu escuro transparente para não misturar com o cenário do fundo
    ctx.fillStyle = "rgba(15, 23, 42, 0.6)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Tamanho e centralização do seu Modal Grande
    let mw = 740, mh = 380;
    let mx = (canvas.width / 2) - (mw / 2);
    let my = (canvas.height / 2) - (mh / 2);

    if (imgModalGrande && imgModalGrande.isReady) ctx.drawImage(imgModalGrande, mx, my, mw, mh);
    else { ctx.fillStyle = "#1E293B"; ctx.fillRect(mx, my, mw, mh); } // Fallback de segurança

    ctx.fillStyle = "#10B981"; ctx.font = "48px 'RiskOfRain'"; ctx.textAlign = "center";
    ctx.fillText("RECICLACOOP", canvas.width / 2, 130);
    ctx.font = "16px 'RiskOfRain'"; ctx.fillStyle = "#94A3B8";
    ctx.fillText("Bem-vindo ao seu primeiro dia no Centro de Triagem RECICLACOOP!", canvas.width / 2, 175);
    ctx.fillText("Bata o ponto para iniciar o expediente.", canvas.width / 2, 185);
    
    desenharBotaoPixelArt("BATER PONTO", botaoStart, "#059669");
    desenharBotaoPixelArt("TUTORIAL", botaoTutorial, "#475569", "#CBD5E1");
    desenharBotaoPixelArt("CONFIG.", botaoConfig, "#475569", "#CBD5E1");
}

export function desenharSelecaoFases() {
    desenharFundoBase();
    
    ctx.fillStyle = "rgba(15, 23, 42, 0.6)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    let mw = 740, mh = 380;
    let mx = (canvas.width / 2) - (mw / 2);
    let my = (canvas.height / 2) - (mh / 2);

    if (imgModalGrande && imgModalGrande.isReady) ctx.drawImage(imgModalGrande, mx, my, mw, mh);
    else { ctx.fillStyle = "#1E293B"; ctx.fillRect(mx, my, mw, mh); }

    ctx.fillStyle = "#ffffff"; ctx.font = "36px 'RiskOfRain'"; ctx.textAlign = "center";
    ctx.fillText("Quadro de Escalas", canvas.width / 2, 80);
    ctx.fillStyle = "#94A3B8"; ctx.font = "16px 'RiskOfRain'";
    ctx.fillText("Selecione o seu setor de trabalho", canvas.width / 2, 110);
    
    for (let b of botoesFases) {
        let liberada = fasesDesbloqueadas[b.fase];
        let hover = (botaoHover === b.id);
        
        // Verifica se a sua arte do botão já existe e está carregada
        if (b.imgNormal && b.imgNormal.isReady) {
            
            // SE A FASE ESTIVER BLOQUEADA
            if (!liberada) {
                if (b.imgBloqueado && b.imgBloqueado.isReady) {
                    // Desenha a sua arte cinza perfeita!
                    ctx.drawImage(b.imgBloqueado, b.x, b.y, b.largura, b.altura);
                } else {
                    // Fallback temporário caso você ainda não tenha salvado a imagem bloqueada
                    ctx.drawImage(b.imgNormal, b.x, b.y, b.largura, b.altura); 
                    ctx.fillStyle = "rgba(15, 23, 42, 0.6)"; ctx.fillRect(b.x, b.y, b.largura, b.altura);
                    ctx.fillStyle = "#FFFFFF"; ctx.font = "20px RiskOfRain"; ctx.fillText("🔒", b.x + (b.largura / 2), b.y + b.altura + 25);
                }
            } 
            // SE A FASE ESTIVER LIBERADA (Animação normal)
            else {
                if (hover && mousePressionado && b.imgHover && b.imgHover.isReady) {
                    ctx.drawImage(b.imgHover, b.x, b.y + 4, b.largura, b.altura); 
                } 
                else if (hover && b.imgHover && b.imgHover.isReady) {
                    ctx.drawImage(b.imgHover, b.x, b.y, b.largura, b.altura); 
                } 
                else {
                    ctx.drawImage(b.imgNormal, b.x, b.y, b.largura, b.altura); 
                }
            }

        } else {
            // FALLBACK PARA RETÂNGULOS (Se a arte normal não existir)
            desenharBotaoPixelArt(b.fase === 5 ? "∞" : "S" + b.fase, b, liberada ? b.cor : "#475569");
            if (!liberada) { ctx.fillStyle = "#FFFFFF"; ctx.font = "20px RiskOfRain"; ctx.fillText("🔒", b.x + (b.largura / 2), b.y + b.altura + 25); }
        }
    }
    
    desenharBotaoPixelArt("VOLTAR", botaoVoltar, "#64748B");
}

export function desenharConfig() {
    desenharFundoBase();
    
    ctx.fillStyle = "rgba(15, 23, 42, 0.6)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    let mw = 740, mh = 380;
    let mx = (canvas.width / 2) - (mw / 2);
    let my = (canvas.height / 2) - (mh / 2);

    if (imgModalGrande && imgModalGrande.isReady) ctx.drawImage(imgModalGrande, mx, my, mw, mh);
    else { ctx.fillStyle = "#1E293B"; ctx.fillRect(mx, my, mw, mh); }

    ctx.fillStyle = "#10B981"; ctx.font = "36px 'RiskOfRain'"; ctx.textAlign = "center"; 
    ctx.fillText("CONFIGURAÇÕES", canvas.width / 2, 80);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'RiskOfRain'"; ctx.fillText("Música", canvas.width / 2, 150);
    desenharBotaoPixelArt("-", btnMusicaMenos, "#475569"); desenharBotaoPixelArt("+", btnMusicaMais, "#475569");
    ctx.font = "bold 24px 'RiskOfRain'"; ctx.fillText(volumeMusica + "%", canvas.width / 2, 198);

    ctx.fillStyle = "#F8FAFC"; ctx.font = "20px 'RiskOfRain'"; ctx.fillText("Efeitos", canvas.width / 2, 240);
    desenharBotaoPixelArt("-", btnEfeitosMenos, "#475569"); desenharBotaoPixelArt("+", btnEfeitosMais, "#475569");
    ctx.font = "bold 24px 'RiskOfRain'"; ctx.fillText(volumeEfeitos + "%", canvas.width / 2, 288);
    desenharBotaoPixelArt("SALVAR", botaoVoltar, "#059669");
}

export function desenharVitoria(timestamp) {
    desenharPartida(timestamp); 
    desenharModalCaixa("FIM DO EXPEDIENTE!", "Meta batida. O supervisor está orgulhoso do seu trabalho!", "#10B981");
}

export function desenharGameOver(timestamp) {
    desenharPartida(timestamp);
    let sub = (faseAtual === 5) ? `Fim da Hora Extra. Você acumulou R$ ${pontos},00.` : `Advertências esgotadas! Desconto no salário: R$ ${pontos},00.`;
    desenharModalCaixa(faseAtual === 5 ? "Turno Encerrado!" : "LENTO DEMAIS! 🚫", sub, faseAtual === 5 ? "#3B82F6" : "#EF4444");
}

export function desenharMenuPausa(timestamp) {
    desenharPartida(timestamp); // Mantém o jogo desenhado no fundo
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Usa a sua arte do Modal Grande para combinar com o Menu
    let mw = 740, mh = 380;
    let mx = (canvas.width / 2) - (mw / 2);
    let my = (canvas.height / 2) - (mh / 2);

    if (imgModalGrande && imgModalGrande.isReady) {
        ctx.drawImage(imgModalGrande, mx, my, mw, mh);
    } else { 
        ctx.fillStyle = "#1E293B"; ctx.fillRect(mx, my, mw, mh); 
    }

    ctx.fillStyle = "#FFFFFF"; ctx.font = "36px 'RiskOfRain'"; ctx.textAlign = "center";
    ctx.fillText("JOGO PAUSADO", canvas.width / 2, 125);
    
    desenharBotaoPixelArt("RETOMAR", botaoRetomar, "#059669");
    desenharBotaoPixelArt("TROCAR DE SETOR", botaoVoltarFases, "#2563EB");
    desenharBotaoPixelArt("VOLTAR AO MENU", botaoVoltarMenu, "#DC2626");
}
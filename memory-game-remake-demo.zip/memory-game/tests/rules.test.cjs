/* Execute: node tests/rules.test.cjs — usa apenas módulos nativos do Node. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const context = { window: {} };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root, 'js/content.js'), 'utf8'), context);
context.Conecta = context.window.Conecta;
for (let n=1;n<=17;n++) vm.runInContext(fs.readFileSync(path.join(root, `js/data/mission-${String(n).padStart(2,'0')}.js`), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(root, 'js/engine.js'), 'utf8'), context);
const {Engine,phases}=context.Conecta;
assert.equal(phases.length,17);
assert.equal(phases.reduce((n,p)=>n+p.pairs.length,0),63);
for(const phase of phases){
 assert.equal(phase.pairs.length,phase.id<=5?3:4);
 const game=new Engine(phase);
 assert.equal(game.deck.length,phase.pairs.length*2);
 for(const pair of phase.pairs){
  const indices=game.deck.flatMap((card,i)=>card.pair.id===pair.id?[i]:[]);
  assert.equal(indices.length,2);
  assert.equal(game.flip(indices[0]).type,'first');
  assert.equal(game.flip(indices[0]),null); // Repetir a mesma carta não é uma tentativa.
  const result=game.flip(indices[1]);
  assert.equal(result.type,'match');
  game.release();
  assert.equal(game.flip(indices[0]),null); // Cartas já resolvidas não rendem XP.
 }
 assert(game.finished);
 assert.equal(game.stars,3);
 assert.equal(game.precision,100);
 assert.equal(game.comboXP,phase.id<=5?30:60);
 assert.equal(game.xp,phase.id<=5?180:260);
}
const game=new Engine(phases[0]);
const a=game.deck.findIndex(c=>c.side==='A');
const wrong=game.deck.findIndex(c=>c.side==='B'&&c.pair.id!==game.deck[a].pair.id);
game.flip(a);assert.equal(game.flip(wrong).type,'miss');assert.equal(game.errors,1);assert.equal(game.xp,0);
game.release();
for(const [errors,stars] of [[0,3],[1,3],[2,2],[3,2],[4,1],[9,1]]){game.errors=errors;assert.equal(game.stars,stars);}
const other=new Engine(phases[0]);other.deck[1]={...other.deck[0]};other.flip(0);assert.equal(other.flip(1).type,'miss'); // Mesmo identificador e mesmo lado não formam um par.
console.log('OK: 17 missões; 63 pares; associação A+B; repetição; erros; combos; precisão; estrelas.');

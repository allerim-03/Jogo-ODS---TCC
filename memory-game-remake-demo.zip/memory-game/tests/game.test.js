import test from 'node:test';
import assert from 'node:assert/strict';
import {MemoryGame,starsFor} from '../js/core/game.js';
import {PHASES,isUnlocked} from '../js/data/phases.js';
import {rememberResult} from '../js/core/progress.js';
test('fases, baralhos e bloqueios',()=>{assert.deepEqual(PHASES.map(p=>new MemoryGame(p).cards.length),[10,10,10,6,36]);assert.equal(isUnlocked(5,{completed:{}}),false);assert.equal(isUnlocked(5,{completed:{4:{stars:1}}}),true);for(const p of PHASES){const g=new MemoryGame(p);for(const id of p.ids)assert.equal(g.cards.filter(c=>c.id===id).length,2);}});
test('partida perfeita, combo, bloqueio e XP',()=>{const g=new MemoryGame(PHASES[0]);for(const id of g.phase.ids){const ix=g.cards.map((c,i)=>c.id===id?i:-1).filter(i=>i>=0);assert.equal(g.flip(ix[0]).type,'first');assert.equal(g.flip(ix[0]),null);const r=g.flip(ix[1]);assert.equal(r.type,'match');assert.equal(g.flip(0),null);g.settle();}assert.equal(g.xp,430);assert.equal(g.moves,5);assert.equal(g.stars,3);assert.equal(g.done,true);assert.equal(g.flip(0),null);});
test('erro interrompe combo e protege cartas durante espera',()=>{const g=new MemoryGame(PHASES[0]);g.combo=2;const a=0,b=g.cards.findIndex(c=>c.id!==g.cards[a].id);g.flip(a);assert.equal(g.flip(b).type,'miss');assert.equal(g.combo,0);assert.equal(g.errors,1);assert.equal(g.flip(2),null);g.settle();assert.ok(g.cards.every(c=>!c.open));assert.equal(g.locked,false);});
test('estrelas e melhor resultado persistente',()=>{assert.equal(starsFor(5,7,2),3);assert.equal(starsFor(5,10,5),2);assert.equal(starsFor(5,11,6),1);const p={completed:{}};rememberResult(p,1,{stars:3,moves:5,seconds:10});rememberResult(p,1,{stars:1,moves:20,seconds:50});assert.deepEqual(p.completed[1],{stars:3,moves:5,seconds:10});});

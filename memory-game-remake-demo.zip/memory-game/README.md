# CONECTA ODS!

Um jogo independente de memória e associação para crianças de 7 a 12 anos. O jogador conecta desafios a ações práticas, acompanhado pelo Tuga, e conquista as 17 insígnias dos Objetivos de Desenvolvimento Sustentável.

## Abrir o jogo

Extraia o ZIP inteiro e abra `index.html` no navegador. Também é possível usar a extensão Live Server do VS Code. Não há dependências para instalar, compilação, conta, login ou servidor obrigatório. Os caminhos antigos `pages/index.html` e `pages/memoryGame.html` redirecionam para a entrada principal.

A área de jogo é de **800 × 452 pixels**, com redução proporcional em telas menores. A interface é feita em HTML, CSS e SVG, mantendo botões acessíveis; não utiliza o elemento HTML `<canvas>`. O progresso é salvo neste navegador. Para uma apresentação em celular, a orientação horizontal oferece cartas maiores.

## Fluxo

Tela inicial → mapa com 17 missões → briefing do Tuga → tabuleiro → superconexões → vitória e insígnia → próxima missão.

- Missões 1 a 5: 6 cartas, em duas linhas de três.
- Missões 6 a 17: 8 cartas, em duas linhas de quatro.
- Cada missão trata de um único ODS, em ordem numérica.
- Só é válido combinar o desafio A com sua ação B correspondente. Cartas de mesmo lado não formam par.
- As fases são desbloqueadas em sequência. Fases concluídas podem ser repetidas.
- Ao acertar, as duas cartas aparecem juntas, com brilho dourado, animação e o texto educativo. O botão Continuar permanece disponível durante o efeito, sem obrigar a espera.
- Não há limite de tempo. O botão de pausa esconde o tabuleiro.
- O álbum permite reler todas as conexões das missões concluídas.

## Pontuação e recompensas

| Evento | XP |
| --- | ---: |
| Par correto | 50 |
| Cada bloco de 2 acertos consecutivos | 30 |
| Conclusão da missão sem erros | 100 |
| Primeira conclusão da missão 17 | 500 extras |

Um erro zera a sequência de combo. Em quatro acertos seguidos, o bônus de combo é recebido no segundo e no quarto acerto. Em três acertos seguidos, há apenas um bônus de 30 XP.

As estrelas seguem o PDF de estrutura: 3 com zero ou um erro; 2 com dois ou três erros; 1 com mais de três erros. Qualquer vitória concede a insígnia do ODS. O melhor resultado em estrelas e em tentativas é preservado. Cada 500 XP acumulados aumenta o nível em 1, começando no nível 1.

O XP exibido no tabuleiro é da partida atual; ele é incorporado ao perfil apenas ao concluir a missão. Abandonar uma missão não concede XP nem insígnia parcial. Repetir uma missão concluída rende o XP da nova partida; o bônus final de 500 XP é concedido somente uma vez.

## Interpretação dos dois roteiros

O conteúdo foi baseado em `ROTEIRO-CARTAS-MEMORYGAME.pdf` e `ESTRUTURA-LÓGICA-MEMORYGAME.pdf`, enviados junto ao pedido. O mapa foi inspirado na imagem de trilha numerada, com vegetação, caminhos e pontos bloqueados.

1. O roteiro fornece 3 pares por ODS. A estrutura exige 4 pares a partir do ODS 6. Os 51 pares originais foram mantidos, com correção de dois erros de digitação, e 12 pares complementares foram acrescentados. Eles estão identificados por `added: true` nos arquivos de dados.
2. As mensagens de vitória do roteiro trazem valores fixos de +150 XP e um exemplo de +180 XP. A interface calcula o total real com a fórmula da estrutura, em vez de exibir um valor fixo incorreto. Uma fase de 3 pares sem erros rende 280 XP; uma fase de 4 pares sem erros rende 360 XP. A primeira vitória final perfeita rende 860 XP.
3. O exemplo de fluxo de Fome Zero cita uma associação diferente da tabela detalhada. Foram usados os pares da tabela: prato vazio → cozinha comunitária; terreno abandonado → horta comunitária; sobras no lixo → aproveitamento integral.
4. As antigas quatro fases temáticas, perguntas bônus e desafio de 36 cartas foram substituídos pelo novo fluxo de 17 missões. O par Chefão ONU → Anel dos 17 ODS está na missão final.
5. A identidade visual e os textos não dependem de plataforma externa. Tuga e as imagens dos ODS fornecidas foram reaproveitados. As cartas usam ícones vetoriais de conceitos e textos para indicar desafios e ações.

### Pares complementares

| Missão | Desafio | Ação |
| --- | --- | --- |
| 6 | Vazamento de água sem conserto | Avisar um adulto e reparar o vazamento |
| 7 | Comunidade sem energia elétrica | Projetos comunitários de energia renovável |
| 8 | Artesãos sem espaço para vender | Feira comunitária de produtos locais |
| 9 | Equipamentos quebrados e abandonados | Oficinas comunitárias de reparo |
| 10 | Colega recém-chegado sem companhia | Acolher e incluir o novo colega |
| 11 | Rua escura no caminho da escola | Solicitar iluminação pública |
| 12 | Pilhas usadas no lixo comum | Levar pilhas a pontos de coleta |
| 13 | Carros usados em trajetos curtos | Caminhar ou pedalar quando for seguro |
| 14 | Animais marinhos perturbados por visitantes | Observar de longe e respeitar seu espaço |
| 15 | Animais silvestres vendidos como bichinhos | Não comprar e avisar um adulto de confiança |
| 16 | Colega sem chance de dar opinião | Roda em que todos possam falar |
| 17 | Praça precisando de cuidados | Mutirão entre moradores, escola e parceiros |

## Organização dos arquivos

| Arquivo ou pasta | Responsabilidade |
| --- | --- |
| `index.html` | Entrada do jogo e ordem de carregamento |
| `js/content.js` | Espaço de nomes exclusivo do jogo |
| `js/data/mission-01.js` a `mission-17.js` | Um arquivo de roteiro por missão |
| `js/engine.js` | Associação A+B, embaralhamento, tentativas, combos e estrelas |
| `js/storage.js` | Perfil, nível, XP, insígnias, recordes e salvamento local |
| `js/app.js` | Navegação e controle do ciclo da partida |
| `js/views.js` | Tela inicial, tabuleiro, cabeçalho e álbum |
| `js/map.js` | Cenário e trilha de 17 missões |
| `js/dialogs.js` | Briefings, conexões, ajuda, vitória e revisão de insígnias |
| `js/icons.js` | Ícones vetoriais locais |
| `js/audio.js` | Sons sintetizados, sem arquivos de áudio externos |
| `css/base.css` | Identidade visual, tela inicial e escala 800 × 452 |
| `css/map.css` | Mapa e álbum |
| `css/game.css` | Tabuleiro, cartas e guia Tuga |
| `css/dialogs.css` | Modais, efeitos de conexão e confetes |
| `imagens/` | Imagens fornecidas dos ODS, ONU e Tuga |
| `tests/rules.test.cjs` | Testes das regras, executáveis com Node |

## Salvamento e acessibilidade

O jogo usa a chave `conecta-ods-v1` do `localStorage`. O progresso anterior, que utilizava outras regras e quatro fases, não é importado automaticamente. Não há comunicação com servidores, rastreamento ou integração com dados da plataforma.

O progresso pertence ao navegador e ao endereço em que o jogo foi aberto. Limpar os dados do navegador pode apagá-lo. Se o navegador impedir o salvamento, o jogo continua durante a sessão e avisa na vitória.

Os botões podem ser acionados pelo teclado. Os diálogos mantêm o foco dentro deles. Cartas ocultas não anunciam seu conteúdo a leitores de tela. Há suporte à preferência de redução de movimento. Os sons começam desligados e podem ser ativados no cabeçalho.

## Verificação realizada

- Percurso completo em Chromium pelas 17 missões e pelas 63 conexões.
- Conferência visual da tela inicial, mapa, briefing, tabuleiros de 6 e 8 cartas, superconexão, vitória final e álbum completo.
- Uma campanha perfeita produz 6.220 XP, 17 insígnias e o Selo de Agente Global.
- Verificados erros, pausa durante resolução, retorno do álbum no meio da jogada, reinício, salvamento após recarregar e bônus final concedido apenas uma vez.
- Conferidas escala de tela estreita, ausência de erros JavaScript e carregamento das imagens.
- Testes locais: execute `node tests/rules.test.cjs` a partir da pasta do jogo.

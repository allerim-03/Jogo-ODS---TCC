/* Missão 8 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 8,
  title: "Trabalho Decente",
  briefing:
    "Vamos valorizar quem trabalha e apoiar os produtores da nossa região!",
  victory: "Missão 8 Concluída! O trabalho justo faz a comunidade crescer!",
  image: "imagens/ods_08_0.png",
  pairs: [
    {
      id: "8-1",
      challenge: "Produtos vindos de muito longe",
      action: "Comprar de feirantes e artesãos locais",
      message:
        "Excelente! Comprar no bairro fortalece os trabalhadores da comunidade!",
      icon: "bus",
      actionIcon: "shop",
    },
    {
      id: "8-2",
      challenge: "Locais de trabalho escuros e perigosos",
      action: "Ambientes seguros e com equipamentos de proteção",
      message:
        "Perfeito! Trabalhar com segurança e respeito é um direito de todos!",
      icon: "tools",
      actionIcon: "shield",
    },
    {
      id: "8-3",
      challenge: "Jovens buscando oportunidade",
      action: "Programas de jovem aprendiz e cursos",
      message:
        "Boa! Dar chances aos jovens prepara profissionais incríveis para o futuro!",
      icon: "help",
      actionIcon: "book",
    },
    {
      id: "8-4",
      challenge: "Artesãos sem espaço para vender",
      action: "Feira comunitária de produtos locais",
      message:
        "Show! Uma feira valoriza o talento e o trabalho da nossa comunidade.",
      icon: "shop",
      added: true,
      actionIcon: "shop",
    },
  ],
});

/* Missão 2 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 2,
  title: "Fome Zero",
  briefing:
    "Hora de combater a fome e garantir comida saudável no prato de todas as crianças!",
  victory:
    "Missão 2 Concluída! O bairro agora tem comida fresca e comunitária!",
  image: "imagens/ods_02_0.png",
  pairs: [
    {
      id: "2-1",
      challenge: "Prato vazio ou sem nutrientes",
      action: "Cozinha comunitária e pratos solidários",
      message:
        "Show! Cozinhas comunitárias preparam refeições quentinhas para todos!",
      icon: "plate",
      actionIcon: "food",
    },
    {
      id: "2-2",
      challenge: "Terreno abandonado e sem uso",
      action: "Horta comunitária com legumes e verduras",
      message:
        "Excelente! Hortas no bairro produzem alimentos frescos e sem veneno!",
      icon: "home",
      actionIcon: "garden",
    },
    {
      id: "2-3",
      challenge: "Sobras de comida indo para o lixo",
      action: "Aproveitamento integral de alimentos",
      message:
        "Boa! Usar cascas e talos evita o desperdício e cria receitas deliciosas!",
      icon: "trash",
      actionIcon: "tools",
    },
  ],
});

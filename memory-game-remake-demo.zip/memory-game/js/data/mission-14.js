/* Missão 14 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 14,
  title: "Vida na Água",
  briefing:
    "Mergulho na missão! Vamos salvar os oceanos e os animais marinhos.",
  victory: "Missão 14 Concluída! Os mares e rios agradecem sua proteção!",
  image: "imagens/ods_14_0.png",
  pairs: [
    {
      id: "14-1",
      challenge: "Plástico flutuando no mar",
      action: "Limpeza de praias e descarte correto",
      message:
        "Boa! Tirar o plástico da praia evita que tartarugas e peixes se machuquem!",
      icon: "trash",
      actionIcon: "broom",
    },
    {
      id: "14-2",
      challenge: "Pesca exagerada em época de filhotes",
      action: "Respeito aos períodos de proteção dos peixes",
      message:
        "Mandou bem! Deixar os peixes crescerem protege a vida nos oceanos!",
      icon: "fish",
      actionIcon: "shield",
    },
    {
      id: "14-3",
      challenge: "Produtos químicos caindo no esgoto",
      action: "Uso de sabões ecológicos e tratamento de água",
      message:
        "Sensacional! Usar produtos limpos mantém a água dos rios saudável!",
      icon: "science",
      actionIcon: "water",
    },
    {
      id: "14-4",
      challenge: "Animais marinhos perturbados por visitantes",
      action: "Observar de longe e respeitar seu espaço",
      message: "Boa! Respeitar os animais ajuda a proteger a vida marinha.",
      icon: "fish",
      added: true,
      actionIcon: "shield",
    },
  ],
});

/* Missão 5 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 5,
  title: "Igualdade de Gênero",
  briefing:
    "Meninos e meninas têm os mesmos direitos e podem ser o que quiserem!",
  victory: "Missão 5 Concluída! O respeito e a igualdade venceram!",
  image: "imagens/ods_05_0.png",
  pairs: [
    {
      id: "5-1",
      challenge: "Esporte ou brinquedo 'só de menino/menina'",
      action: "Meninos e meninas jogando e brincando juntos",
      message: "Mandou muito! Esportes e brincadeiras são para todo mundo!",
      icon: "play",
      actionIcon: "people",
    },
    {
      id: "5-2",
      challenge: "Tarefas de casa concentradas em uma pessoa",
      action: "Divisão justa das tarefas entre a família",
      message:
        "Show! Ajudar em casa deixa a rotina da família leve e justa para todos!",
      icon: "home",
      actionIcon: "people",
    },
    {
      id: "5-3",
      challenge: "Meninas sem espaço na tecnologia",
      action: "Clubes de robótica e ciência para meninas",
      message:
        "Super! Meninas podem ser grandes cientistas, inventoras e astronautas!",
      icon: "science",
      actionIcon: "science",
    },
  ],
});

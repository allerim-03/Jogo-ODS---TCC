/* Missão 6 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 6,
  title: "Água Potável e Saneamento",
  briefing:
    "Água limpa é vida! Vamos economizar e proteger nossas fontes de água.",
  victory: "Missão 6 Concluída! Cada gota de água guardada faz a diferença!",
  image: "imagens/ods_06_0.png",
  pairs: [
    {
      id: "6-1",
      challenge: "Torneira aberta ao escovar os dentes",
      action: "Fechar a torneira e usar copo d'água",
      message:
        "Boa! Fechar a torneira economiza milhares de litros de água tratada!",
      icon: "tap",
      actionIcon: "tap",
    },
    {
      id: "6-2",
      challenge: "Rio do bairro cheio de garrafas",
      action: "Mutirão de limpeza nas margens do rio",
      message:
        "Incrível! Tirar o lixo dos rios mantém a água limpa para a natureza!",
      icon: "trash",
      actionIcon: "broom",
    },
    {
      id: "6-3",
      challenge: "Desperdício de água limpa na faxina",
      action: "Captação de água da chuva em cisternas",
      message:
        "Perfeito! Reutilizar a água da chuva é uma ideia super inteligente!",
      icon: "water",
      actionIcon: "rain",
    },
    {
      id: "6-4",
      challenge: "Vazamento de água sem conserto",
      action: "Avisar um adulto e reparar o vazamento",
      message:
        "Conexão feita! Consertar vazamentos evita perder água todos os dias.",
      icon: "water",
      added: true,
      actionIcon: "tools",
    },
  ],
});

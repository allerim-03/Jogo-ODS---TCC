/* Missão 12 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 12,
  title: "Consumo Responsável",
  briefing: "Repensar o que compramos, reutilizar objetos e reduzir o lixo!",
  victory: "Missão 12 Concluída! Você aprendeu a consumir com sabedoria!",
  image: "imagens/ods_12_0.png",
  pairs: [
    {
      id: "12-1",
      challenge: "Brinquedo quebrado indo para o lixo",
      action: "Feira de troca e oficina de consertos",
      message:
        "Perfeito! Consertar ou trocar brinquedos dá vida nova aos objetos!",
      icon: "trash",
      actionIcon: "tools",
    },
    {
      id: "12-2",
      challenge: "Excesso de sacolas plásticas descartáveis",
      action: "Uso de sacolas de pano (ecobags) nas compras",
      message:
        "Mandou bem! Sacolas reutilizáveis evitam pilhas de plástico no planeta!",
      icon: "bag",
      actionIcon: "bag",
    },
    {
      id: "12-3",
      challenge: "Comprar coisas novas sem precisar",
      action: "Consumo consciente e reutilização de materiais",
      message:
        "Boa! Comprar só o necessário ajuda o bolso e economiza recursos!",
      icon: "shop",
      actionIcon: "recycle",
    },
    {
      id: "12-4",
      challenge: "Pilhas usadas no lixo comum",
      action: "Levar pilhas a pontos de coleta",
      message:
        "Perfeito! O descarte correto de pilhas ajuda a proteger o solo e a água.",
      icon: "recycle",
      added: true,
      actionIcon: "recycle",
    },
  ],
});

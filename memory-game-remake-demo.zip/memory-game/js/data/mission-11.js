/* Missão 11 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 11,
  title: "Cidades Sustentáveis",
  briefing:
    "Vamos transformar a cidade em um lugar verde, limpo e seguro para morar!",
  victory: "Missão 11 Concluída! Sua cidade agora é verde e acolhedora!",
  image: "imagens/ods_11_0.png",
  pairs: [
    {
      id: "11-1",
      challenge: "Ruas cheias de trânsito e fumaça",
      action: "Uso de ciclovias, caminhadas e ônibus",
      message:
        "Boa! Usar bicicleta deixa o ar mais limpo e a cidade mais livre!",
      icon: "bus",
      actionIcon: "bike",
    },
    {
      id: "11-2",
      challenge: "Praça cinzenta e sem vida",
      action: "Plantio de jardins e árvores no bairro",
      message:
        "Incrível! Árvores trazem sombra, ar puro e passarinhos para a cidade!",
      icon: "home",
      actionIcon: "garden",
    },
    {
      id: "11-3",
      challenge: "Lixo espalhado pelas calçadas",
      action: "Lixeiras organizadas e coleta seletiva",
      message:
        "Sensacional! Manter a rua limpa é dever de todo cidadão consciente!",
      icon: "trash",
      actionIcon: "recycle",
    },
    {
      id: "11-4",
      challenge: "Rua escura no caminho da escola",
      action: "Solicitar iluminação pública para a rua",
      message:
        "Boa! A iluminação ajuda a tornar os caminhos da comunidade mais seguros.",
      icon: "bulb",
      added: true,
      actionIcon: "bulb",
    },
  ],
});

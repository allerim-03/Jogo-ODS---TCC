/* Missão 15 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 15,
  title: "Vida Terrestre",
  briefing:
    "Hora de proteger as florestas, plantas e todos os animais terrestres!",
  victory: "Missão 15 Concluída! As florestas estão mais vivas do que nunca!",
  image: "imagens/ods_15_0.png",
  pairs: [
    {
      id: "15-1",
      challenge: "Área verde desmatada",
      action: "Reflorestamento com árvores nativas",
      message:
        "Incrível! Plantar árvores devolve a casa dos animais da floresta!",
      icon: "tree",
      actionIcon: "garden",
    },
    {
      id: "15-2",
      challenge: "Animais silvestres fora do habitat",
      action: "Proteção da fauna e resgate animal",
      message: "Perfeito! Proteger os animais mantém a natureza em equilíbrio!",
      icon: "animal",
      actionIcon: "shield",
    },
    {
      id: "15-3",
      challenge: "Risco de queimadas na mata",
      action: "Prevenção de incêndios e brigadas ecológicas",
      message:
        "Mandou muito! Cuidar da mata evita queimadas e salva a vegetação!",
      icon: "fire",
      actionIcon: "shield",
    },
    {
      id: "15-4",
      challenge: "Animais silvestres vendidos como bichinhos",
      action: "Não comprar e avisar um adulto de confiança",
      message:
        "Conexão feita! Animais silvestres precisam de proteção em seu ambiente natural.",
      icon: "animal",
      added: true,
      actionIcon: "shield",
    },
  ],
});

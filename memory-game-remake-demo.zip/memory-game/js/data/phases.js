export const PHASES = [
{id:1,title:'Pessoas e Sociedade',subtitle:'Cuidar de gente transforma o mundo.',ids:[1,2,3,4,5],question:'Qual ODS defende uma educação de qualidade?',options:[2,4,5],answer:4},
{id:2,title:'Planeta e Recursos',subtitle:'Nosso planeta, nossa responsabilidade.',ids:[6,12,13,14,15],question:'Qual ODS protege florestas e animais terrestres?',options:[6,14,15],answer:15},
{id:3,title:'Prosperidade e Infraestrutura',subtitle:'Construir um futuro com oportunidades.',ids:[7,8,9,10,11],question:'Qual ODS incentiva energia limpa e acessível?',options:[7,9,11],answer:7},
{id:4,title:'Paz e Parcerias',subtitle:'Uma missão especial: unir forças com a ONU.',ids:[16,17,18],question:'Qual ODS destaca as parcerias para alcançar os objetivos?',options:[16,17,18],answer:17},
{id:5,title:'Mestre dos ODS',subtitle:'18 pares. 3 minutos. Uma grande missão.',ids:Array.from({length:18},(_,i)=>i+1),limit:180,question:'Qual ODS incentiva o consumo responsável?',options:[12,13,14],answer:12}
];
export const isUnlocked = (id,progress) => id===1 || Boolean(progress.completed[id-1]);

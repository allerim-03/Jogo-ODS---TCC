/* Missão 9 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 9,
  title: "Indústria e Inovação",
  briefing: "Hora de criar invenções inteligentes para melhorar as cidades!",
  victory: "Missão 9 Concluída! Ideias inovadoras transformam o mundo!",
  image: "imagens/ods_09_0.png",
  pairs: [
    {
      id: "9-1",
      challenge: "Produtos que quebram rápido e viram lixo",
      action: "Invenções com materiais reciclados e duráveis",
      message:
        "Mandou bem! Criar coisas duráveis evita a poluição do meio ambiente!",
      icon: "trash",
      actionIcon: "recycle",
    },
    {
      id: "9-2",
      challenge: "Pessoas sem acesso à internet",
      action: "Pontos de wi-fi público em praças e bibliotecas",
      message:
        "Incrível! A internet comunitária ajuda todos a pesquisar e aprender!",
      icon: "wifi",
      actionIcon: "wifi",
    },
    {
      id: "9-3",
      challenge: "Calçadas sem acesso para cadeirantes",
      action: "Construção de rampas de acessibilidade",
      message:
        "Boa! Cidades bem planejadas garantem a passagem de todas as pessoas!",
      icon: "access",
      actionIcon: "access",
    },
    {
      id: "9-4",
      challenge: "Equipamentos quebrados e abandonados",
      action: "Oficinas comunitárias de reparo",
      message:
        "Incrível! Consertar equipamentos aproveita materiais e estimula novas ideias.",
      icon: "tools",
      added: true,
      actionIcon: "tools",
    },
  ],
});

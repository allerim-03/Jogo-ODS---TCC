const rows = [
['Erradicação da pobreza','e5243b','Toda pessoa merece viver com dignidade.','Doe roupas em bom estado e participe de ações solidárias.'],
['Fome zero e agricultura sustentável','dda63a','Comida de verdade deve chegar a todas as pessoas.','Coloque no prato só o que vai comer e valorize produtores locais.'],
['Saúde e bem-estar','4c9f38','Cuidar de você também é cuidar do futuro.','Movimente o corpo, lave as mãos e reserve tempo para descansar.'],
['Educação de qualidade','c5192d','Aprender abre caminhos e transforma vidas.','Compartilhe o que aprendeu e ajude um colega com dificuldades.'],
['Igualdade de gênero','ff3a21','Meninas e meninos merecem as mesmas oportunidades.','Divida tarefas e respeite as escolhas de cada pessoa.'],
['Água potável e saneamento','26bde2','Água limpa é essencial para a vida.','Feche a torneira ao escovar os dentes e avise sobre vazamentos.'],
['Energia limpa e acessível','fcc30b','Energia pode iluminar o futuro sem poluir tanto.','Apague as luzes ao sair e aproveite a iluminação natural.'],
['Trabalho decente e crescimento econômico','a21942','Todo trabalho merece respeito e condições seguras.','Valorize os trabalhadores e os pequenos negócios do seu bairro.'],
['Indústria, inovação e infraestrutura','fd6925','Boas ideias ajudam a construir um mundo melhor.','Crie soluções para economizar recursos na escola e em casa.'],
['Redução das desigualdades','dd1367','Ninguém deve ficar para trás.','Inclua quem está sozinho e respeite as diferenças.'],
['Cidades e comunidades sustentáveis','fd9d24','Uma cidade melhor é feita para todas as pessoas.','Cuide das praças e caminhe ou use bicicleta quando for seguro.'],
['Consumo e produção responsáveis','bf8b2e','Menos desperdício, mais futuro!','Evite desperdiçar comida e separe o lixo reciclável.'],
['Ação contra a mudança global do clima','3f7e44','Pequenas atitudes fazem parte de uma grande mudança.','Economize energia e converse sobre como proteger o clima.'],
['Vida na água','0a97d9','Oceanos saudáveis protegem a vida do planeta.','Economize água no banho e não jogue lixo na rua: ele pode chegar ao mar.'],
['Vida terrestre','56c02b','Florestas e animais precisam de proteção.','Cuide das plantas e nunca retire animais de seu habitat.'],
['Paz, justiça e instituições eficazes','00689d','O respeito é o primeiro passo para a paz.','Resolva conflitos com diálogo e procure ajuda contra a violência.'],
['Parcerias e meios de implementação','19486a','Juntos conseguimos transformar mais.','Junte amigos, escola e comunidade em uma ação pelo planeta.'],
['ONU · União pelo planeta','5984b4','O desafio final é cooperar!','Escolha um ODS e convide alguém para colocar uma ação em prática.']
];
export const ODS = rows.map(([name,color,impact,action],i)=>({id:i+1,name,color:'#'+color,impact,action,image:i===17?'onu.png':`ods_${String(i+1).padStart(2,'0')}_${i===0?1:0}.png`}));
export const getODS = id => ODS.find(o=>o.id===id);

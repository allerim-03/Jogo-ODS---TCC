/* Missão 17 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 17,
  title: "Parcerias pelas Metas",
  briefing:
    "Missão Final! A união faz a força: vamos conectar todos os ODS para salvar o planeta!",
  victory:
    "PARABÉNS, AGENTE GLOBAL! Você completou todas as missões, conquistou o Selo ODS e aprendeu como transformar o mundo de verdade!",
  image: "imagens/ods_17_0.png",
  pairs: [
    {
      id: "17-1",
      challenge: "Uma pessoa tentando mudar tudo sozinha",
      action: "Parceria entre escola, comunidade e famílias",
      message:
        "Incrível! Quando todos trabalham juntos, grandes sonhos viram realidade!",
      icon: "help",
      actionIcon: "people",
    },
    {
      id: "17-2",
      challenge: "Boas ideias guardadas sem compartilhar",
      action: "Feira de projetos e troca de ideias entre escolas",
      message:
        "Show! Compartilhar boas soluções ajuda outros bairros a evoluírem!",
      icon: "bulb",
      actionIcon: "chat",
    },
    {
      id: "17-3",
      challenge: "Carta Chefão ONU (Símbolo Global)",
      action: "Anel dos 17 ODS Unidos",
      message:
        "SUPER CONEXÃO! Todos os 17 Objetivos unidos constroem um futuro perfeito!",
      icon: "globe",
      actionIcon: "globe",
    },
    {
      id: "17-4",
      challenge: "Uma praça precisando de cuidados",
      action: "Mutirão entre moradores, escola e parceiros",
      message:
        "SUPER-CONEXÃO! Cada pessoa contribui e, juntas, elas transformam a comunidade.",
      icon: "people",
      added: true,
      actionIcon: "people",
    },
  ],
});

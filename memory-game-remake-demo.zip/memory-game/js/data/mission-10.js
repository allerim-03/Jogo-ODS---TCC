/* Missão 10 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 10,
  title: "Redução das Desigualdades",
  briefing:
    "Respeitar as diferenças e dar oportunidades iguais para todas as pessoas!",
  victory: "Missão 10 Concluída! Um mundo sem barreiras é um mundo melhor!",
  image: "imagens/ods_10_0.png",
  pairs: [
    {
      id: "10-1",
      challenge: "Parquinho onde nem todos conseguem brincar",
      action: "Brinquedos adaptados para crianças com deficiência",
      message:
        "Perfeito! Parquinhos inclusivos deixam todas as crianças brincarem juntas!",
      icon: "play",
      actionIcon: "access",
    },
    {
      id: "10-2",
      challenge: "Bullying e piadas de mau gosto",
      action: "Rodas de conversa sobre empatia e respeito",
      message:
        "Show! Tratar os colegas com carinho faz a escola ser um lugar feliz!",
      icon: "chat",
      actionIcon: "heart",
    },
    {
      id: "10-3",
      challenge: "Bairros distantes sem transporte público",
      action: "Linhas de ônibus para todas as comunidades",
      message:
        "Mandou muito! Oportunidades iguais chegam a todos os cantos da cidade!",
      icon: "home",
      actionIcon: "bus",
    },
    {
      id: "10-4",
      challenge: "Colega recém-chegado sem companhia",
      action: "Acolher e incluir o novo colega",
      message:
        "Mandou bem! Receber cada pessoa com respeito faz todos se sentirem parte da turma.",
      icon: "people",
      added: true,
      actionIcon: "heart",
    },
  ],
});

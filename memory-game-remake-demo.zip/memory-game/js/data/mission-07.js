/* Missão 7 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 7,
  title: "Energia Limpa e Acessível",
  briefing: "Vamos acender o futuro usando a luz do sol e a força do vento!",
  victory: "Missão 7 Concluída! A energia do futuro é limpa e brilhante!",
  image: "imagens/ods_07_0.png",
  pairs: [
    {
      id: "7-1",
      challenge: "Luzes acesas em cômodos vazios",
      action: "Desligar lâmpadas e aparelhos sem uso",
      message:
        "Mandou bem! Apagar as luzes economiza energia e protege o planeta!",
      icon: "bulb",
      actionIcon: "lightoff",
    },
    {
      id: "7-2",
      challenge: "Usinas poluentes queimando combustível",
      action: "Painéis de energia solar nos telhados",
      message: "Sensacional! O sol gera energia limpa sem soltar fumaça no ar!",
      icon: "factory",
      actionIcon: "solar",
    },
    {
      id: "7-3",
      challenge: "Lâmpadas antigas que esquentam muito",
      action: "Troca por lâmpadas LED econômicas",
      message:
        "Show! Lâmpadas LED gastam muito menos energia e duram muito mais!",
      icon: "bulb",
      actionIcon: "bulb",
    },
    {
      id: "7-4",
      challenge: "Comunidade sem energia elétrica",
      action: "Projetos comunitários de energia renovável",
      message:
        "Boa! Compartilhar energia limpa ajuda mais famílias a estudar e viver melhor.",
      icon: "sun",
      added: true,
      actionIcon: "solar",
    },
  ],
});

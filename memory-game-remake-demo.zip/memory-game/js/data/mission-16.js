/* Missão 16 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 16,
  title: "Paz e Justiça",
  briefing: "Promover a paz, o diálogo e a amizade em todos os lugares!",
  victory: "Missão 16 Concluída! A paz e a amizade venceram este desafio!",
  image: "imagens/ods_16_0.png",
  pairs: [
    {
      id: "16-1",
      challenge: "Desentendimentos na hora de brincar",
      action: "Conversa amigável e mediação de conflitos",
      message: "Boa! Resolver problemas conversando fortalece as amizades!",
      icon: "chat",
      actionIcon: "chat",
    },
    {
      id: "16-2",
      challenge: "Regras da sala impostas sem conversa",
      action: "Votação e combinados feitos por todos",
      message:
        "Mandou bem! Decidir as regras juntos garante que todos sejam ouvidos!",
      icon: "vote",
      actionIcon: "vote",
    },
    {
      id: "16-3",
      challenge: "Falta de honestidade nas brincadeiras",
      action: "Jogo limpo, honestidade e respeito",
      message: "Perfeito! Ser honesto cria confiança entre os amigos!",
      icon: "play",
      actionIcon: "heart",
    },
    {
      id: "16-4",
      challenge: "Um colega sem chance de dar opinião",
      action: "Criar uma roda em que todos possam falar",
      message: "Incrível! Escutar cada pessoa torna as decisões mais justas.",
      icon: "chat",
      added: true,
      actionIcon: "people",
    },
  ],
});

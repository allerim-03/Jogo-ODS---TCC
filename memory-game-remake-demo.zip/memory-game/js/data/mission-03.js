/* Missão 3 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 3,
  title: "Saúde e Bem-Estar",
  briefing:
    "Vamos cuidar do corpo, da mente e da saúde de toda a nossa comunidade!",
  victory: "Missão 3 Concluída! A saúde da galera está em dia graças a você!",
  image: "imagens/ods_03_0.png",
  pairs: [
    {
      id: "3-1",
      challenge: "Vírus e doenças transmissíveis",
      action: "Vacinação em dia e mutirões de saúde",
      message: "Perfeito! Tomar vacinas protege você e todos ao seu redor!",
      icon: "virus",
      actionIcon: "syringe",
    },
    {
      id: "3-2",
      challenge: "Crianças sem espaço para brincar",
      action: "Praça limpa com brinquedos e esportes",
      message:
        "Isso aí! Praticar esportes ao ar livre deixa o corpo forte e a mente feliz!",
      icon: "home",
      actionIcon: "play",
    },
    {
      id: "3-3",
      challenge: "Água parada e acúmulo de sujeira",
      action: "Combate a focos da dengue e limpeza",
      message:
        "Mandou bem! Tirar água parada evita mosquitos e protege a saúde dos vizinhos!",
      icon: "water",
      actionIcon: "broom",
    },
  ],
});

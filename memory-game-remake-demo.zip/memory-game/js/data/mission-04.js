/* Missão 4 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 4,
  title: "Educação de Qualidade",
  briefing:
    "Aprender é um superpoder! Vamos garantir que todas as crianças consigam estudar.",
  victory: "Missão 4 Concluída! As portas do conhecimento foram abertas!",
  image: "imagens/ods_04_0.png",
  pairs: [
    {
      id: "4-1",
      challenge: "Crianças sem livros para ler",
      action: "Doação de livros e biblioteca comunitária",
      message:
        "Fantástico! Doar livros abre portas para novas histórias e conhecimentos!",
      icon: "book",
      actionIcon: "book",
    },
    {
      id: "4-2",
      challenge: "Dificuldade na matéria da escola ",
      action: "Reforço escolar com tutores voluntários ",
      message:
        "Boa! Ajudar um colega nos estudos faz todo mundo aprender junto!",
      icon: "help",
      actionIcon: "people",
    },
    {
      id: "4-3",
      challenge: "Escola com paredes desbotadas",
      action: "Mutirão de pintura e reformas escolares",
      message:
        "Incrível! Uma escola bonita e colorida dá muito mais vontade de estudar!",
      icon: "home",
      actionIcon: "brush",
    },
  ],
});

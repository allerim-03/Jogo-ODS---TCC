/* Missão 1 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 1,
  title: "Erradicação da Pobreza",
  briefing:
    "Boas-vindas, Agente! Nossa primeira missão é unir forças para ajudar as famílias a terem o básico para viver com dignidade.",
  victory:
    "Missão 1 Concluída! Você ajudou a levar carinho e suprimentos para quem precisava!",
  image: "imagens/ods_01_1.png",
  pairs: [
    {
      id: "1-1",
      challenge: "Pessoas passando frio no inverno",
      action: "Campanha do agasalho e doação de roupas",
      message:
        "Incrível! Doar agasalhos aquecidos protege quem mais precisa no frio!",
      icon: "cold",
      actionIcon: "coat",
    },
    {
      id: "1-2",
      challenge: "Famílias sem comida em casa",
      action: "Arrecadação de cestas básicas na escola",
      message:
        "Mandou bem! Cestas básicas garantem alimento na mesa das famílias.",
      icon: "food",
      actionIcon: "basket",
    },
    {
      id: "1-3",
      challenge: "Falta de oportunidades de aprendizado",
      action: "Oficinas gratuitas de capacitação",
      message:
        "Par perfeito! Ensinar novas habilidades ajuda os adultos a conseguirem trabalho!",
      icon: "book",
      actionIcon: "people",
    },
  ],
});

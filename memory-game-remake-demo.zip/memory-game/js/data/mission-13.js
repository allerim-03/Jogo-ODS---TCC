/* Missão 13 — conteúdo do roteiro. */
Conecta.phases.push({
  id: 13,
  title: "Ação pelo Clima",
  briefing:
    "SOS Planeta! Vamos unir forças para combater o aquecimento global!",
  victory: "Missão 13 Concluída! Você é um verdadeiro Defensor do Clima!",
  image: "imagens/ods_13_0.png",
  pairs: [
    {
      id: "13-1",
      challenge: "Poluição esquentando o planeta",
      action: "Plantio de árvores que purificam o ar",
      message:
        "Incrível! As árvores sugam a poluição e ajudam a esfriar o planeta!",
      icon: "factory",
      actionIcon: "garden",
    },
    {
      id: "13-2",
      challenge: "Falta de informação sobre o clima",
      action: "Projetos escolares de conscientização",
      message: "Show! Ensinar sobre o clima faz todo mundo mudar de atitude!",
      icon: "help",
      actionIcon: "people",
    },
    {
      id: "13-3",
      challenge: "Lixo orgânico soltando gases",
      action: "Compostagem doméstica de restos de alimentos",
      message:
        "Perfeito! Compostar o lixo transforma restos de comida em adubo natural!",
      icon: "trash",
      actionIcon: "garden",
    },
    {
      id: "13-4",
      challenge: "Carros usados em trajetos curtos",
      action: "Caminhar ou pedalar quando for seguro",
      message:
        "Show! Caminhar e pedalar reduzem emissões e ajudam a cuidar do clima.",
      icon: "bike",
      added: true,
      actionIcon: "bike",
    },
  ],
});

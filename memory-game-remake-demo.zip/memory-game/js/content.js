/* Espaço de nomes exclusivo do jogo. Missões carregadas na ordem do roteiro. */
window.Conecta = { phases: [] };

Conecta.audio = {
  context: null,
  play(victory = false) {
    if (!Conecta.store.data.sound) return;
    try {
      this.context ||= new (window.AudioContext || window.webkitAudioContext)();
      this.context.resume();
      (victory ? [523, 659, 784, 1046] : [659, 880]).forEach((frequency, i) => {
        const o = this.context.createOscillator(),
          g = this.context.createGain(),
          t = this.context.currentTime + i * 0.12;
        o.type = "sine";
        o.frequency.value = frequency;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.1, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
        o.connect(g);
        g.connect(this.context.destination);
        o.start(t);
        o.stop(t + 0.24);
      });
    } catch {}
  },
};

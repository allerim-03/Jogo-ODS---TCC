/* Cenário vetorial e trilha navegável: os botões continuam sendo HTML acessível. */
Conecta.landscape = () =>
  `<svg class="landscape" viewBox="0 0 800 392" aria-hidden="true"><defs><pattern id="grass" width="57" height="39" patternUnits="userSpaceOnUse"><path d="M9 16h6m25 16h4" stroke="#b2cc8e" stroke-width="2" stroke-linecap="round" opacity=".5"/></pattern><g id="tree"><path d="M0 0v23" stroke="#ad995f" stroke-width="4"/><rect x="-10" y="-30" width="20" height="42" rx="10" fill="#4CAF50"/><path d="M0-28v37" stroke="#8fd06a" stroke-width="7" stroke-linecap="round"/></g></defs><rect width="800" height="392" fill="#e4edc5"/><rect width="800" height="392" fill="url(#grass)"/><path d="M-30 315Q60 245 102 320t98 35 90-17 120 62" fill="none" stroke="#b6e1d0" stroke-width="39"/><path d="M-30 315Q60 245 102 320t98 35 90-17 120 62" fill="none" stroke="#88cbb9" stroke-width="3" stroke-dasharray="20 24"/><path d="M33 100q-30-40 22-51t85 5 9 61-85 29zM341 182q-43-29 8-47t83 2 9 63-75 11zM640 300q-25-43 28-50t77 17-4 63-67 11z" fill="#d2e78b"/><use href="#tree" x="66" y="91"/><use href="#tree" x="98" y="104"/><use href="#tree" x="376" y="171"/><use href="#tree" x="409" y="182"/><use href="#tree" x="685" y="295"/><use href="#tree" x="718" y="310"/><g transform="translate(585 175)"><path d="M-23 0 0-22 23 0" fill="#FF8637"/><rect x="-18" width="36" height="28" rx="3" fill="#fff4d2"/><rect x="-5" y="12" width="10" height="16" fill="#aa8f63"/><path d="M-10 6h4m12 0h4" stroke="#43B4FB" stroke-width="5"/></g><g transform="translate(165 231)"><rect width="34" height="23" rx="4" fill="#c49a56"/><path d="M0 8h34M17 0v23" stroke="#f5d77f" stroke-width="5"/></g><g fill="#f5ca5a"><circle cx="481" cy="104" r="4"/><circle cx="495" cy="113" r="3"/><circle cx="320" cy="286" r="4"/></g></svg>`;
Conecta.mapView = () => {
  const C = Conecta,
    s = C.store;
  const points = [
    [66, 266],
    [105, 202],
    [176, 156],
    [258, 168],
    [337, 218],
    [422, 244],
    [510, 226],
    [588, 170],
    [664, 110],
    [726, 148],
    [714, 238],
    [640, 299],
    [552, 317],
    [464, 306],
    [376, 318],
    [280, 300],
    [202, 332],
  ];
  const route = points
    .map(([x, y], i) => `${i ? "L" : "M"}${x} ${y}`)
    .join(" ");
  return `<div class="map-scene">${C.landscape()}<div class="map-heading"><div class="eyebrow">SEU MAPA DE MISSÕES</div><h1>Pequenas conexões.<br>Grandes mudanças.</h1><p>Um objetivo por vez. Um mundo melhor para todos.</p></div><div class="map-counter">${C.icon("medal")}<b>${s.completed}<small>/ 17 selos</small></b></div><svg class="route" viewBox="0 0 800 392" aria-hidden="true"><path d="${route}" fill="none" stroke="#fcf9e9" stroke-width="13" stroke-linejoin="round" stroke-linecap="round"/><path d="${route}" fill="none" stroke="#aaba91" stroke-width="4" stroke-dasharray="4 8" stroke-linecap="round"/>${points
    .slice(1)
    .map((point, i) =>
      s.data.stars[i]
        ? `<path d="M${points[i]}L${point}" stroke="#4CAF50" fill="none" stroke-width="4" stroke-linecap="round"/>`
        : "",
    )
    .join("")}</svg>${points
    .map(([x, y], i) => {
      const available = s.unlocked(i),
        stars = s.data.stars[i];
      return `<button class="map-node ${stars ? "done" : available ? "current" : "locked"} ${i === 16 ? "final-node" : ""}" style="left:${x}px;top:${y}px" data-phase="${i}" aria-label="Missão ${i + 1}: ${C.phases[i].title}. ${stars ? stars + " estrelas" : available ? "Disponível" : "Bloqueada"}" ${available ? "" : "disabled"}><b>${i + 1}</b>${!available ? C.icon("lock") : stars ? `<span class="node-stars">${"★".repeat(stars)}</span>` : '<span class="node-tag">VAMOS!</span>'}</button>`;
    })
    .join(
      "",
    )}<div class="map-caption">${C.icon("link")} Conecte o desafio à ação que transforma.</div></div>`;
};

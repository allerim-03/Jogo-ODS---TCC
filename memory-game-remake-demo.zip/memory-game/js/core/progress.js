const KEY='tuga-memory-v2';
const empty=()=>({xp:0,album:[],completed:{},sound:true});
export function loadProgress(){
  try { const p=JSON.parse(localStorage.getItem(KEY)); if(!p||typeof p!=='object')return empty();
    return {xp:Number.isFinite(p.xp)?Math.max(0,p.xp):0,album:Array.isArray(p.album)?p.album.filter(n=>Number.isInteger(n)&&n>=1&&n<=18):[],completed:p.completed&&typeof p.completed==='object'?p.completed:{},sound:p.sound!==false};
  } catch {return empty();}
}
export function saveProgress(p){try{localStorage.setItem(KEY,JSON.stringify(p));return true;}catch{return false;}}
export function rememberResult(p,id,result){
 const old=p.completed[id];
 p.completed[id]={stars:Math.max(old?.stars||0,result.stars),moves:Math.min(old?.moves??Infinity,result.moves),seconds:Math.min(old?.seconds??Infinity,result.seconds)};
}

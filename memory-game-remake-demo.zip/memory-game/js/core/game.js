export function shuffle(items,random=Math.random){
 const result=[...items];for(let i=result.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[result[i],result[j]]=[result[j],result[i]];}return result;
}
export const starsFor=(pairs,moves,errors)=>moves<=pairs+2&&errors<=2?3:moves<=pairs*2&&errors<=pairs?2:1;
export class MemoryGame{
 constructor(phase){this.phase=phase;this.cards=shuffle(phase.ids.flatMap(id=>[{id,matched:false,open:false},{id,matched:false,open:false}]));this.moves=0;this.errors=0;this.combo=0;this.xp=0;this.pairs=0;this.first=null;this.locked=false;this.done=false;}
 flip(index){
  const card=this.cards[index];if(this.done||this.locked||!card||card.open||card.matched)return null;
  card.open=true;
  if(this.first===null){this.first=index;return {type:'first'};}
  this.moves++;const a=this.cards[this.first];this.locked=true;
  if(a.id!==card.id){this.errors++;this.combo=0;return {type:'miss'};}
  a.matched=card.matched=true;this.pairs++;this.combo++;
  const earned=50+(this.combo>1?20:0);this.xp+=earned;this.done=this.pairs===this.phase.ids.length;
  const perfect=this.done&&this.moves===this.phase.ids.length?100:0;this.xp+=perfect;
  return {type:'match',id:card.id,earned,perfect,done:this.done};
 }
 settle(){this.cards.forEach(c=>{if(!c.matched)c.open=false;});this.first=null;this.locked=false;}
 get stars(){return starsFor(this.phase.ids.length,this.moves,this.errors);}
}

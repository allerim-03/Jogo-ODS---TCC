/* Controlador de navegação e ciclo da missão. Sem dependência da plataforma. */
(() => {
  const C = Conecta,
    V = C.views,
    D = C.dialogs,
    S = C.store,
    screen = document.querySelector("#screen");
  let view = "home",
    game = null,
    phaseIndex = 0,
    session = 0,
    busy = false,
    paused = false,
    pending = null,
    albumReturn = "home",
    confirmAction = null;
  function render(next) {
    view = next;
    V.header(next !== "home");
    screen.innerHTML =
      next === "home"
        ? V.home()
        : next === "map"
          ? C.mapView()
          : next === "album"
            ? V.album()
            : V.board(game);
    if (next === "game") V.sync(game);
  }
  function leave(next) {
    session++;
    game = null;
    busy = false;
    paused = false;
    pending = null;
    D.close();
    render(next);
  }
  function briefing(index) {
    if (!S.unlocked(index)) return;
    session++;
    phaseIndex = index;
    game = null;
    busy = false;
    paused = false;
    pending = null;
    render("map");
    D.briefing(C.phases[index]);
  }
  function start() {
    session++;
    game = new C.Engine(C.phases[phaseIndex]);
    busy = false;
    paused = false;
    pending = null;
    D.close();
    render("game");
  }
  function resume() {
    D.close();
    paused = false;
    if (pending) {
      const fn = pending;
      pending = null;
      fn();
    }
  }
  function schedule(fn, delay) {
    const current = session;
    setTimeout(() => {
      if (current !== session) return;
      if (paused || view !== "game") {
        pending = fn;
        return;
      }
      fn();
    }, delay);
  }
  function guard(action) {
    if (
      view !== "game" ||
      !game ||
      game.finished ||
      (game.attempts === 0 && game.open.length === 0)
    ) {
      action();
      return;
    }
    paused = true;
    confirmAction = action;
    D.show(
      `<span class="pill">SUA MISSÃO AINDA NÃO ACABOU</span><h2 id="dialog-title">Quer sair desta partida?</h2><p class="connection-message">O XP desta partida é guardado quando você conclui a missão. Os selos já conquistados continuam no seu álbum.</p><div class="dialog-actions"><button class="secondary" data-dialog="resume">Continuar jogando</button><button class="primary" data-dialog="confirm-leave">Sair da partida</button></div>`,
    );
  }
  function album() {
    if (view === "album") return;
    albumReturn = view;
    paused = true;
    render("album");
  }
  function flip(index) {
    if (
      view !== "game" ||
      busy ||
      paused ||
      !document.querySelector("#overlay").hidden
    )
      return;
    const result = game.flip(index);
    if (!result) return;
    V.sync(game);
    if (result.type === "first") return;
    busy = true;
    const mascot = document.querySelector("#guide-tuga"),
      message = document.querySelector("#guide-message");
    if (result.type === "miss") {
      mascot.className = "thinking";
      message.textContent =
        "Ainda não! Pense em qual ação resolve esse desafio.";
      schedule(() => {
        game.release();
        busy = false;
        V.sync(game);
        mascot.className = "";
      }, 850);
      return;
    }
    mascot.className = "happy";
    message.textContent = result.combo
      ? "Combo! Duas conexões seguidas. +30 XP!"
      : "Mandou bem! Essa ação faz a diferença.";
    C.audio.play();
    D.connection(result.pair, result.xp, result.combo);
  }
  function finish() {
    const result = S.complete(game);
    V.header(true);
    D.victory(game, result);
    C.audio.play(true);
    D.confetti();
  }
  document.querySelector("#game").addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button || button.disabled) return;
    const inDialog = Boolean(button.closest("#overlay"));
    if (!document.querySelector("#overlay").hidden && !inDialog) return;
    if (button.dataset.phase !== undefined)
      return briefing(Number(button.dataset.phase));
    if (button.dataset.card !== undefined)
      return flip(Number(button.dataset.card));
    if (button.dataset.seal !== undefined)
      return D.seal(C.phases[Number(button.dataset.seal)]);
    if (button.dataset.review !== undefined)
      return D.seal(
        C.phases[Number(button.dataset.phaseId) - 1],
        Number(button.dataset.review),
      );
    switch (button.dataset.action) {
      case "home":
        guard(() => leave("home"));
        return;
      case "map":
        guard(() => leave("map"));
        return;
      case "sound":
        S.data.sound = !S.data.sound;
        S.save();
        V.header(view !== "home");
        C.audio.play();
        return;
      case "album":
        album();
        return;
      case "album-back":
        if (albumReturn === "game" && game) {
          render("game");
          resume();
        } else leave(albumReturn);
        return;
      case "help":
        D.help();
        return;
      case "restart":
        guard(start);
        return;
      case "pause":
        paused = true;
        D.show(
          `<span class="pill">PAUSA</span><h2 id="dialog-title">Respire. Sua missão espera!</h2><p class="connection-message">Continue quando estiver pronto para fazer novas conexões.</p><button class="primary" data-dialog="resume">Continuar missão</button>`,
        );
        return;
    }
    switch (button.dataset.dialog) {
      case "start":
        start();
        break;
      case "cancel-brief":
        D.close();
        break;
      case "continue":
        D.close();
        game.release();
        busy = false;
        if (game.finished) finish();
        else V.sync(game);
        break;
      case "next":
        if (phaseIndex === 16) {
          D.close();
          albumReturn = "map";
          game = null;
          render("album");
        } else briefing(phaseIndex + 1);
        break;
      case "retry":
        start();
        break;
      case "map":
        leave("map");
        break;
      case "resume":
        resume();
        break;
      case "confirm-leave": {
        const action = confirmAction;
        confirmAction = null;
        action();
        break;
      }
      case "seal-close":
      case "help-close":
        D.close();
        break;
    }
  });
  document.addEventListener("visibilitychange", () => {
    if (
      document.hidden &&
      view === "game" &&
      !game.finished &&
      document.querySelector("#overlay").hidden
    )
      document.querySelector('[data-action="pause"]').click();
  });
  function fit() {
    const scale = Math.min(
      1,
      window.innerWidth / 800,
      window.innerHeight / 452,
    );
    document.querySelector("#viewport").style.cssText =
      `width:${800 * scale}px;height:${452 * scale}px`;
    document.querySelector("#game").style.transform = `scale(${scale})`;
  }
  window.addEventListener("resize", fit);
  fit();
  render("home");
})();

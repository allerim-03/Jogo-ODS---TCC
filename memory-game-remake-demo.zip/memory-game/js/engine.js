/* Regras de associação. Mesmo par, lados diferentes: desafio A + ação B. */
Conecta.Engine = class {
  constructor(phase, rng = Math.random) {
    this.phase = phase;
    this.deck = phase.pairs.flatMap((pair) =>
      ["A", "B"].map((side) => ({ pair, side })),
    );
    for (let i = this.deck.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [this.deck[i], this.deck[j]] = [this.deck[j], this.deck[i]];
    }
    this.open = [];
    this.matched = new Set();
    this.attempts = 0;
    this.errors = 0;
    this.streak = 0;
    this.xp = 0;
    this.comboXP = 0;
    this.finished = false;
  }
  flip(index) {
    if (
      this.finished ||
      this.open.length >= 2 ||
      this.open.includes(index) ||
      this.matched.has(index) ||
      !this.deck[index]
    )
      return null;
    this.open.push(index);
    if (this.open.length === 1) return { type: "first" };
    this.attempts++;
    const [a, b] = this.open.map((i) => this.deck[i]);
    if (a.pair.id !== b.pair.id || a.side === b.side) {
      this.errors++;
      this.streak = 0;
      return { type: "miss" };
    }
    this.open.forEach((i) => this.matched.add(i));
    this.streak++;
    const combo = this.streak % 2 === 0 ? 30 : 0;
    this.comboXP += combo;
    this.xp += 50 + combo;
    this.finished = this.matched.size === this.deck.length;
    return {
      type: "match",
      pair: a.pair,
      xp: 50 + combo,
      combo,
      complete: this.finished,
    };
  }
  release() {
    this.open = [];
  }
  get stars() {
    return this.errors <= 1 ? 3 : this.errors <= 3 ? 2 : 1;
  }
  get precision() {
    return this.finished && this.errors === 0 ? 100 : 0;
  }
};

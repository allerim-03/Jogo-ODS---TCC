/* Telas e componentes; conteúdo e regras ficam em módulos próprios. */
Conecta.views = {
  header(back = false) {
    const C = Conecta,
      s = C.store;
    document.querySelector("#header").innerHTML =
      `<div class="header-left">${back ? `<button class="circle light" data-action="home" aria-label="Tela inicial">${C.icon("home")}</button>` : ""}<button class="wordmark" data-action="home" aria-label="CONECTA ODS! Tela inicial">CONECTA <b>ODS!</b><span>UMA AVENTURA DE CONEXÕES</span></button></div><div class="profile"><span class="level">${C.icon("star")} NÍVEL ${s.level}</span><div class="xp"><b>${s.data.xp} XP</b><span class="xp-track"><i style="width:${(s.data.xp % 500) / 5}%"></i></span></div><button class="circle light" data-action="sound" aria-label="${s.data.sound ? "Desativar" : "Ativar"} som">${C.icon(s.data.sound ? "sound" : "mute")}</button><button class="circle purple" data-action="album" aria-label="Álbum de insígnias">${C.icon("album")}</button></div>`;
  },
  home() {
    const C = Conecta,
      s = C.store;
    return `<div class="home-scene">${C.landscape()}<div class="hero-copy"><div class="eyebrow">17 MISSÕES • UM PLANETA • VOCÊ</div><h1>O mundo precisa<br>das suas <em>conexões!</em></h1><p>Junte cada desafio a uma boa ação.<br>Faça descobertas e torne-se um Agente Global!</p><button class="primary" data-action="map">${s.completed ? "Continuar aventura" : "Começar aventura"} ${C.icon("arrow")}</button><button class="text-button" data-action="help">${C.icon("help")} Como jogar</button></div><div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><span class="art-badge sun-badge">${C.icon("sun")}</span><span class="art-badge water-badge">${C.icon("water")}</span><span class="art-badge leaf-badge">${C.icon("tree")}</span><div class="tuga-halo"><img src="imagens/Tuga.png" alt="Tuga, sua tartaruga guia"></div><div class="hero-speech"><b>Oi! Eu sou o Tuga.</b><span>Vamos transformar o mundo juntos?</span></div><span class="tiny-star star-one">✦</span><span class="tiny-star star-two">✦</span></div><div class="home-bottom"><span>${C.icon("link")} Memória + boas atitudes</span><span>${C.icon("medal")} ${s.completed} de 17 insígnias</span><button data-action="album">Abrir meu álbum ${C.icon("arrow")}</button></div></div>`;
  },
  cardFace(card) {
    const C = Conecta,
      p = card.pair;
    const boss = p.id === "17-3";
    return `<div class="face-kind">${card.side === "A" ? "DESAFIO" : "SUPER-AÇÃO"}</div><div class="card-drawing">${boss && card.side === "A" ? '<img src="imagens/onu.png" alt="Símbolo da ONU">' : boss ? '<span class="ods-ring"></span>' : C.icon(card.side === "A" ? p.icon : p.actionIcon || p.icon)}<span class="drawing-mark">${card.side === "A" ? "?" : C.icon("check")}</span></div><span class="face-text">${card.side === "A" ? p.challenge : p.action}</span>`;
  },
  board(game) {
    const C = Conecta,
      p = game.phase;
    return `<div class="play-scene"><div class="play-status"><div class="phase-info"><img src="${p.image}" alt="ODS ${p.id}"><div><span>MISSÃO ${String(p.id).padStart(2, "0")} / 17</span><h1>${p.title}</h1></div></div><div class="attempt-stat"><b id="attempts">${game.attempts}</b><span>TENTATIVAS</span></div><div class="run-stat">${C.icon("star")}<b id="run-xp">${game.xp} XP</b></div></div><div class="board" style="--columns:${p.pairs.length}">${game.deck.map((card, index) => `<button class="memory-card ${card.side === "A" ? "challenge-card" : "action-card"}" data-card="${index}" aria-label="Carta ${index + 1}, virada para baixo"><span class="card-inner"><span class="card-back"><span class="back-symbol">${C.icon("link")}</span><b>CONECTA</b><small>ODS!</small><i></i></span><span class="card-front" aria-hidden="true">${this.cardFace(card)}</span></span></button>`).join("")}</div><div class="guide"><img id="guide-tuga" src="imagens/Tuga.png" alt="Tuga, seu guia"><p id="guide-message" aria-live="polite">Procure um <b>desafio</b> e a <b>ação</b> que o resolve!</p><span id="pair-count">0 / ${p.pairs.length} conexões</span><button class="circle light" data-action="pause" aria-label="Pausar">${C.icon("pause")}</button><button class="circle light" data-action="restart" aria-label="Recomeçar missão">${C.icon("replay")}</button><button class="circle light" data-action="map" aria-label="Voltar ao mapa">${C.icon("back")}</button></div></div>`;
  },
  sync(game) {
    document.querySelectorAll("[data-card]").forEach((el, i) => {
      const visible = game.open.includes(i) || game.matched.has(i),
        card = game.deck[i];
      el.classList.toggle("flipped", visible);
      el.classList.toggle("matched", game.matched.has(i));
      el.disabled = game.matched.has(i);
      el.querySelector(".card-front").setAttribute(
        "aria-hidden",
        String(!visible),
      );
      el.setAttribute(
        "aria-label",
        visible
          ? `${card.side === "A" ? "Desafio" : "Super-ação"}: ${card.side === "A" ? card.pair.challenge : card.pair.action}${game.matched.has(i) ? ", conexão encontrada" : ""}`
          : `Carta ${i + 1}, virada para baixo`,
      );
    });
    document.querySelector("#attempts").textContent = game.attempts;
    document.querySelector("#run-xp").textContent = game.xp + " XP";
    document.querySelector("#pair-count").textContent =
      `${game.matched.size / 2} / ${game.phase.pairs.length} conexões`;
  },
  album() {
    const C = Conecta,
      s = C.store;
    return `<div class="album-scene"><div class="album-heading"><div><div class="eyebrow">ÁLBUM DO AGENTE GLOBAL</div><h1>Suas conexões viraram conquistas.</h1></div><span>${s.completed} / 17</span></div><div class="album-grid">${C.phases.map((p, i) => `<button class="seal ${s.data.stars[i] ? "earned" : "unearned"}" data-seal="${i}" ${s.data.stars[i] ? "" : "disabled"} aria-label="ODS ${p.id}: ${p.title}, ${s.data.stars[i] ? "insígnia conquistada" : "conclua a missão para desbloquear"}">${s.data.stars[i] ? `<img src="${p.image}" alt="">` : C.icon("lock")}<span>ODS ${p.id}</span><small>${s.data.stars[i] ? "★".repeat(s.data.stars[i]) : "A conquistar"}</small></button>`).join("")}<div class="seal global-seal ${s.data.globalSeal ? "earned" : "unearned"}">${C.icon("medal")}<span>AGENTE GLOBAL</span><small>${s.data.globalSeal ? "Selo conquistado!" : "Complete as 17"}</small></div></div><div class="album-footer"><span>Conclua uma missão para conquistar seu selo. Toque para rever suas conexões.</span><button class="secondary" data-action="album-back">${C.icon("back")} Voltar</button></div></div>`;
  },
};

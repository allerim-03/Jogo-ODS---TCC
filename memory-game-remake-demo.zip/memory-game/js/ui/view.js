import {getODS} from '../data/ods.js';
export const $=id=>document.getElementById(id);
export const time=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(Math.floor(n%60)).padStart(2,'0')}`;
export const stars=n=>'★'.repeat(n)+'☆'.repeat(3-n);
export function renderBoard(game){
 $('board').classList.toggle('master',Boolean(game.phase.limit));
 $('board').innerHTML=game.cards.map((c,i)=>{const o=getODS(c.id);return `<button class="memory-card ${c.open?'open':''} ${c.matched?'matched':''}" data-index="${i}" aria-label="${c.open||c.matched?o.name:`Carta ${i+1}, fechada`}" ${c.matched?'disabled':''}><span class="card-back" aria-hidden="true"><span>✦</span></span><span class="card-front" aria-hidden="true"><img src="../imagens/${o.image}" alt=""></span></button>`;}).join('');
}
export function updateBoard(game){
 [...$('board').children].forEach((el,i)=>{const c=game.cards[i];el.classList.toggle('open',c.open);el.classList.toggle('matched',c.matched);el.disabled=c.matched;el.setAttribute('aria-label',c.open||c.matched?getODS(c.id).name:`Carta ${i+1}, fechada`);});
 $('moves').textContent=game.moves;$('errors').textContent=game.errors;$('round-xp').textContent=game.xp;$('pairs').textContent=`${game.pairs} / ${game.phase.ids.length}`;
}
export function dialog(title,body,actions){
 const d=$('dialog');$('dialog-title').textContent=title;$('dialog-body').innerHTML=body;$('dialog-actions').replaceChildren();
 actions.forEach(({label,run,secondary})=>{const b=document.createElement('button');b.className=secondary?'button secondary':'button';b.textContent=label;b.onclick=()=>{d.close();run?.();};$('dialog-actions').append(b);});
 if(!d.open)d.showModal();
}

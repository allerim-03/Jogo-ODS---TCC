let context;
export function sound(enabled,victory=false){
 if(!enabled)return;
 try{context??=new (window.AudioContext||window.webkitAudioContext)();context.resume().catch(()=>{});
 (victory?[523,659,784,1047]:[659,880]).forEach((f,i)=>{const o=context.createOscillator(),g=context.createGain(),t=context.currentTime+i*.12;o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.12,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.22);o.connect(g);g.connect(context.destination);o.start(t);o.stop(t+.24);});}catch{}
}
export function confetti(){
 if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 const layer=document.getElementById('confetti');layer.replaceChildren();
 for(let i=0;i<55;i++){const bit=document.createElement('i');bit.style.cssText=`left:${Math.random()*100}%;background:${['#a68bc4','#e7aacb','#80cabb','#ecca73'][i%4]};animation-delay:${Math.random()*.5}s;transform:rotate(${Math.random()*360}deg)`;layer.append(bit);}
 setTimeout(()=>layer.replaceChildren(),3000);
}

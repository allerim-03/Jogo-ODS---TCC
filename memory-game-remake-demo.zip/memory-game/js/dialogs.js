/* Briefings, conexão educativa, resumo de vitória e revisão do álbum. */
Conecta.dialogs = {
  show(html, kind = "") {
    const overlay = document.querySelector("#overlay");
    this.previousFocus = document.activeElement;
    overlay.innerHTML = `<section class="dialog ${kind}" role="dialog" aria-modal="true" aria-labelledby="dialog-title">${html}</section>`;
    overlay.hidden = false;
    document.querySelector("#header").inert = true;
    document.querySelector("#screen").inert = true;
    overlay.querySelector("button")?.focus();
  },
  close() {
    document.querySelector("#overlay").hidden = true;
    document.querySelector("#overlay").innerHTML = "";
    document.querySelector("#header").inert = false;
    document.querySelector("#screen").inert = false;
    this.previousFocus?.focus();
  },
  briefing(phase) {
    this.show(
      `<span class="pill">MISSÃO ${String(phase.id).padStart(2, "0")} DE 17</span><div class="briefing-heading"><img src="${phase.image}" alt="ODS ${phase.id}"><h2 id="dialog-title">${phase.title}</h2></div><div class="briefing-body"><img src="imagens/Tuga.png" alt="Tuga dá as boas-vindas"><p>${phase.briefing}</p></div><div class="mission-tip">${Conecta.icon("link")} Conecte ${phase.pairs.length} desafios às ações que os resolvem.</div><div class="dialog-actions"><button class="secondary" data-dialog="cancel-brief">Voltar ao mapa</button><button class="primary" data-dialog="start">Vamos conectar! ${Conecta.icon("arrow")}</button></div>`,
      "briefing",
    );
  },
  connection(pair, xp, combo) {
    this.show(
      `<span class="pill gold">${combo ? "COMBO! " : ""}+${xp} XP</span><h2 id="dialog-title">SUPER-CONEXÃO!</h2><div class="connection-pair"><div class="connection-card challenge-card"><div class="card-front">${Conecta.views.cardFace({ pair, side: "A" })}</div></div><span class="gold-link">${Conecta.icon("link")}</span><div class="connection-card action-card"><div class="card-front">${Conecta.views.cardFace({ pair, side: "B" })}</div></div></div><p class="connection-message">${pair.message}</p><button class="primary" data-dialog="continue">Continuar! ${Conecta.icon("arrow")}</button>`,
      "connection",
    );
  },
  victory(game, result) {
    const C = Conecta;
    this.show(
      `<span class="pill gold">${game.phase.id === 17 ? "AVENTURA COMPLETA" : "MISSÃO CUMPRIDA"}</span><h2 id="dialog-title">${game.phase.id === 17 ? "Parabéns, Agente Global!" : "Uma conexão muda tudo!"}</h2><div class="victory-stars" aria-label="${game.stars} estrelas">${[1, 2, 3].map((n) => `<span class="${n <= game.stars ? "on" : ""}">${C.icon("star")}</span>`).join("")}</div><p class="victory-copy">${game.phase.victory.replace(/^Missão \d+ Concluída!\s*/, "").replace(/^PARABÉNS, AGENTE GLOBAL!\s*/, "")}</p><div class="reward-summary"><img src="${game.phase.image}" alt="Insígnia ODS ${game.phase.id} conquistada"><div><strong>+${result.reward} XP</strong><span>${game.phase.id === 17 ? "Selo de Agente Global conquistado!" : `Selo ODS ${game.phase.id} conquistado!`}</span></div><div class="attempt-result"><b>${game.attempts}</b><span>tentativas · ${game.errors} erros</span></div></div><div class="xp-details"><span>Pares <b>+${game.phase.pairs.length * 50}</b></span><span>Combos <b>+${game.comboXP}</b></span><span>Precisão <b>+${game.precision}</b></span>${result.globalBonus ? "<span>Bônus final <b>+500</b></span>" : ""}</div><div class="dialog-actions"><button class="secondary" data-dialog="retry">${C.icon("replay")} Jogar de novo</button><button class="primary" data-dialog="next">${game.phase.id === 17 ? "Ver meu álbum" : "Próxima missão"} ${C.icon("arrow")}</button></div><button class="text-button centered" data-dialog="map">Voltar ao mapa</button>${!C.store.persistent ? '<p class="save-note">Este navegador não permitiu salvar. O progresso fica disponível enquanto o jogo estiver aberto.</p>' : ""}`,
      "victory",
    );
  },
  seal(phase, index = 0) {
    const pair = phase.pairs[index];
    this.show(
      `<span class="pill">SELO ODS ${phase.id} · CONEXÃO ${index + 1} / ${phase.pairs.length}</span><h2 id="dialog-title">${phase.title}</h2><div class="review-connection"><span><small>DESAFIO</small>${pair.challenge}</span>${Conecta.icon("link")}<span><small>SUPER-AÇÃO</small>${pair.action}</span></div><p class="connection-message">${pair.message}</p><div class="dialog-actions"><button class="secondary" data-dialog="seal-close">Fechar</button><button class="primary" data-review="${(index + 1) % phase.pairs.length}" data-phase-id="${phase.id}">Ver outra conexão ${Conecta.icon("arrow")}</button></div>`,
      "seal-dialog",
    );
  },
  help() {
    this.show(
      `<span class="pill">COMO JOGAR</span><h2 id="dialog-title">Memória com propósito!</h2><ol class="help-list"><li>Escolha uma missão no mapa e leia a proposta do Tuga.</li><li>Vire duas cartas. Conecte um <b>desafio</b> à <b>ação que o resolve</b>. As imagens não precisam ser iguais!</li><li>Leia a superconexão, encontre todos os pares e conquiste seu selo.</li></ol><div class="help-score">+50 XP por par · +30 XP a cada 2 acertos seguidos<br>+100 XP sem erros · +500 XP na primeira vitória final</div><p class="help-stars">3 estrelas: até 1 erro · 2 estrelas: 2 ou 3 erros<br>1 estrela: mais de 3 erros · Sem limite de tempo.</p><button class="primary" data-dialog="help-close">Entendi. Vamos lá!</button>`,
    );
  },
  confetti() {
    const box = document.querySelector("#confetti");
    box.innerHTML = "";
    for (let i = 0; i < 40; i++) {
      const el = document.createElement("i");
      el.style.cssText = `left:${Math.random() * 100}%;background:${["#4CAF50", "#43B4FB", "#FFDE5A", "#FF8637", "#DB95FD", "#FF524D"][i % 6]};animation-delay:${Math.random() * 0.3}s`;
      box.append(el);
    }
    setTimeout(() => (box.innerHTML = ""), 2300);
  },
};
document.addEventListener("keydown", (e) => {
  if (e.key !== "Tab" || document.querySelector("#overlay").hidden) return;
  const buttons = [
    ...document.querySelectorAll("#overlay button:not(:disabled)"),
  ];
  if (!buttons.length) return;
  if (e.shiftKey && document.activeElement === buttons[0]) {
    e.preventDefault();
    buttons.at(-1).focus();
  } else if (!e.shiftKey && document.activeElement === buttons.at(-1)) {
    e.preventDefault();
    buttons[0].focus();
  }
});

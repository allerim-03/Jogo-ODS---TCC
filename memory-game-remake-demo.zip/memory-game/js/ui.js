/* Componentes visuais e diálogos; todas as dimensões usam a área base 800 × 452. */
ODS.ui = {
  screen: document.querySelector("#screen"),
  overlay: document.querySelector("#overlay"),
  totals() {
    document.querySelector("#total-xp").textContent =
      `✦ ${ODS.store.data.xp} XP`;
  },
  modal(html) {
    this.previousFocus = document.activeElement;
    this.overlay.innerHTML = `<section class="modal" role="dialog" aria-modal="true" aria-label="Missão ODS">${html}</section>`;
    this.overlay.hidden = false;
    this.overlay.querySelector("button")?.focus();
  },
  close() {
    this.overlay.hidden = true;
    this.overlay.innerHTML = "";
    this.previousFocus?.focus();
  },
  home() {
    const d = ODS.store.data;
    this.screen.innerHTML = `<div class="welcome"><div class="welcome-copy"><div class="eyebrow">APRENDA • COMBINE • TRANSFORME</div><h1>Uma memória incrível.<br>Um mundo melhor.</h1><p>Encontre os pares e descubra os 17 Objetivos<br>de Desenvolvimento Sustentável.</p></div><img class="tuga" src="imagens/Tuga.png" alt="Tuga, nossa tartaruga guia"><div class="speech"><b>Oi, eu sou o Tuga!</b><br>Vamos cuidar do mundo juntos?<br>Complete cada missão, ganhe XP e colecione descobertas!</div></div><div class="section-label"><span>ESCOLHA SUA MISSÃO</span><span class="small">${d.stars.slice(0, 4).filter(Boolean).length} de 4 fases concluídas</span></div><div class="missions">${ODS.phases
      .slice(0, 4)
      .map(
        (p, i) =>
          `<button class="mission ${ODS.store.unlocked(i) ? "" : "locked"}" data-phase="${i}" style="--accent:${ODS.colors[p.color]}" ${ODS.store.unlocked(i) ? "" : "disabled"}><span class="number">FASE 0${i + 1}</span><span class="stars">${"★".repeat(d.stars[i])}${"☆".repeat(3 - d.stars[i])}</span><h3>${p.title}</h3><span class="small">${ODS.store.unlocked(i) ? `${p.ids.length * 2} cartas · Jogar →` : "Conclua a fase anterior"}</span></button>`,
      )
      .join(
        "",
      )}</div><button class="challenge" data-phase="4" ${ODS.store.unlocked(4) ? "" : "disabled"}><b>✦ Mestre dos ODS</b><span>${ODS.store.unlocked(4) ? "36 cartas · 3 minutos · Jogar →" : "Conclua as 4 missões para desbloquear"}</span></button>`;
  },
  board(game, index) {
    const p = game.phase;
    this.screen.innerHTML = `<div class="play-layout"><aside class="side"><div class="level-pill">${index === 4 ? "DESAFIO" : `FASE 0${index + 1}`}</div><div class="round-actions"><button id="back" aria-label="Voltar às missões">←</button><button id="pause" aria-label="Pausar jogo">Ⅱ</button></div><div class="stat xp"><strong id="xp">0</strong><span>XP NESTA MISSÃO</span></div><div class="stat"><strong id="time">${p.limit ? "03:00" : "00:00"}</strong><span>${p.limit ? "TEMPO RESTANTE" : "TEMPO DE JOGO"}</span></div><div class="stat"><strong id="moves">0</strong><span>JOGADAS</span></div></aside><div class="board-area"><div class="board-title"><h2>${p.title}</h2><span id="pairs">0 / ${p.ids.length} pares</span></div><div class="board ${index === 4 ? "full" : p.ids.length === 3 ? "six" : ""}" aria-label="Tabuleiro de cartas">${game.deck.map((id, i) => `<button class="card" data-index="${i}" aria-label="Carta ${i + 1}, virada para baixo"><img src="${ODS.cards[id - 1].image}" alt=""></button>`).join("")}</div><div class="board-status" id="status" aria-live="polite">Encontre os pares. Cada descoberta transforma!</div></div><aside class="side"><button class="tool blue" id="peek"><b>◉</b>Espiar cartas<small>Uma vez por partida</small></button><button class="tool green" id="in-album"><b>▧</b>Meu álbum<small>${ODS.store.data.album.length} / 18 figurinhas</small></button><button class="tool orange" id="restart"><b>↻</b>Recomeçar</button><p class="small">+50 XP por par<br>+20 XP por combo<br>Ideal: ${game.ideal} jogadas</p></aside></div>`;
  },
  sync(game) {
    document.querySelectorAll(".card").forEach((el, i) => {
      const found = game.matched.has(i),
        open = game.open.includes(i);
      el.classList.toggle("revealed", open);
      el.classList.toggle("matched", found);
      el.disabled = found;
      el.setAttribute(
        "aria-label",
        found || open
          ? `${ODS.cards[game.deck[i] - 1].title}${found ? ", par encontrado" : ""}`
          : `Carta ${i + 1}, virada para baixo`,
      );
    });
    document.querySelector("#xp").textContent = game.xp;
    document.querySelector("#moves").textContent = game.moves;
    document.querySelector("#pairs").textContent =
      `${game.matched.size / 2} / ${game.ideal} pares`;
    this.totals();
  },
  learn(id, after, reward = "NOVA DESCOBERTA") {
    const c = ODS.cards[id - 1];
    this.modal(
      `<span class="badge">${reward}</span><h2>${id === 18 ? "ONU" : `ODS ${id}`} · ${c.title}</h2><img class="sticker" src="${c.image}" alt="${c.title}"><p>${c.impact}</p><div class="action"><b>Experimente hoje:</b> ${c.action}</div><div class="row"><button class="primary" id="continue">Continuar →</button></div>`,
    );
    document.querySelector("#continue").onclick = () => {
      this.close();
      after();
    };
  },
  album() {
    const d = ODS.store.data;
    this.screen.innerHTML = `<div class="album-head"><div><div class="eyebrow">CADA PAR, UMA DESCOBERTA</div><h2>Meu álbum dos ODS</h2></div><button id="album-back" class="secondary">← Voltar</button></div><div class="album-grid">${ODS.cards.map((c) => `<button class="album-card" data-sticker="${c.id}" ${d.album.includes(c.id) ? "" : "disabled"}>${d.album.includes(c.id) ? `<img src="${c.image}" alt=""><span><b>${c.id === 18 ? "ONU" : `ODS ${c.id}`}</b><br>Ver descoberta</span>` : `<span class="lock">◇</span><span>${c.id === 18 ? "ONU" : `ODS ${c.id}`}<br>Encontre o par</span>`}</button>`).join("")}</div><p class="album-note">${d.album.length} de 18 figurinhas coletadas · Clique nas descobertas para rever uma ação prática.</p>`;
  },
  confetti() {
    const box = document.querySelector("#particles");
    box.innerHTML = "";
    for (let i = 0; i < 35; i++) {
      const c = document.createElement("i");
      c.className = "confetti";
      c.style.cssText = `left:${Math.random() * 100}%;background:${ODS.colors[i % 6]};animation-delay:${Math.random() * 0.4}s`;
      box.append(c);
    }
    setTimeout(() => (box.innerHTML = ""), 2500);
  },
};
// Contém o foco no diálogo para navegação por teclado.
document.addEventListener("keydown", (e) => {
  if (e.key !== "Tab" || ODS.ui.overlay.hidden) return;
  const a = [...ODS.ui.overlay.querySelectorAll("button:not(:disabled)")];
  if (!a.length) return;
  if (e.shiftKey && document.activeElement === a[0]) {
    e.preventDefault();
    a.at(-1).focus();
  } else if (!e.shiftKey && document.activeElement === a.at(-1)) {
    e.preventDefault();
    a[0].focus();
  }
});

/* Conteúdo pedagógico e configuração das missões. */
window.ODS = {};
ODS.colors = ["#4CAF50", "#43B4FB", "#FFDE5A", "#FF8637", "#DB95FD", "#FF524D"];
ODS.cards = [
  [
    1,
    "Erradicação da pobreza",
    "Toda pessoa merece viver com dignidade.",
    "Doe roupas em bom estado e apoie ações solidárias.",
  ],
  [
    2,
    "Fome zero",
    "Comida de qualidade é um direito de todos.",
    "Sirva só o que vai comer e evite desperdícios.",
  ],
  [
    3,
    "Saúde e bem-estar",
    "Cuidar de você também transforma o mundo.",
    "Movimente o corpo, beba água e cuide do seu descanso.",
  ],
  [
    4,
    "Educação de qualidade",
    "Aprender abre caminhos para o futuro.",
    "Compartilhe o que aprendeu e ajude um colega.",
  ],
  [
    5,
    "Igualdade de gênero",
    "Meninas e meninos merecem as mesmas oportunidades.",
    "Divida tarefas e respeite as escolhas de cada pessoa.",
  ],
  [
    6,
    "Água potável e saneamento",
    "Água limpa é vida para todos.",
    "Feche a torneira ao escovar os dentes.",
  ],
  [
    7,
    "Energia limpa e acessível",
    "Energia pode cuidar do planeta.",
    "Apague as luzes ao sair e aproveite a luz do sol.",
  ],
  [
    8,
    "Trabalho decente",
    "Trabalhar com respeito é um direito.",
    "Valorize quem trabalha e respeite todas as profissões.",
  ],
  [
    9,
    "Indústria e inovação",
    "Boas ideias ajudam a resolver problemas.",
    "Crie soluções que economizem materiais e energia.",
  ],
  [
    10,
    "Redução das desigualdades",
    "Todo mundo merece ter oportunidades.",
    "Inclua quem ficou de fora das brincadeiras.",
  ],
  [
    11,
    "Cidades sustentáveis",
    "Uma cidade melhor começa com a gente.",
    "Cuide das praças e prefira caminhar quando for seguro.",
  ],
  [
    12,
    "Consumo responsável",
    "Consumir com cuidado ajuda o planeta a respirar!",
    "Evite desperdiçar comida e separe o lixo reciclável.",
  ],
  [
    13,
    "Ação contra a mudança do clima",
    "O clima precisa da nossa ajuda.",
    "Economize energia e use transportes menos poluentes.",
  ],
  [
    14,
    "Vida na água",
    "Oceanos saudáveis protegem a vida.",
    "Economize água no banho e não jogue lixo na rua.",
  ],
  [
    15,
    "Vida terrestre",
    "Florestas e animais precisam de proteção.",
    "Cuide das plantas e respeite os animais silvestres.",
  ],
  [
    16,
    "Paz e justiça",
    "Respeito e diálogo constroem a paz.",
    "Resolva conflitos conversando e procure ajuda contra a violência.",
  ],
  [
    17,
    "Parcerias pelas metas",
    "Juntos, conseguimos transformar mais.",
    "Convide amigos para uma ação em favor da comunidade.",
  ],
  [
    18,
    "Chefão ONU",
    "A missão final é unir forças!",
    "Escolha um ODS e combine uma ação com sua turma.",
  ],
].map(([id, title, impact, action]) => ({
  id,
  title,
  impact,
  action,
  image:
    id === 18
      ? "imagens/onu.png"
      : `imagens/ods_${String(id).padStart(2, "0")}_${id === 1 ? 1 : 0}.png`,
}));
ODS.phases = [
  {
    title: "Pessoas e Sociedade",
    subtitle: "Cuidar de quem está ao nosso lado.",
    ids: [1, 2, 3, 4, 5],
    color: 0,
    question: "Qual ODS defende oportunidades iguais para meninas e meninos?",
    options: [
      "ODS 5 • Igualdade de gênero",
      "ODS 2 • Fome zero",
      "ODS 7 • Energia limpa",
    ],
    answer: 0,
  },
  {
    title: "Planeta e Recursos",
    subtitle: "Proteger a nossa casa em comum.",
    ids: [6, 12, 13, 14, 15],
    color: 1,
    question: "Qual ODS protege as florestas e os animais terrestres?",
    options: [
      "ODS 6 • Água potável",
      "ODS 15 • Vida terrestre",
      "ODS 14 • Vida na água",
    ],
    answer: 1,
  },
  {
    title: "Prosperidade e Infraestrutura",
    subtitle: "Construir um futuro para todos.",
    ids: [7, 8, 9, 10, 11],
    color: 3,
    question: "Qual atitude ajuda a construir cidades sustentáveis?",
    options: [
      "Jogar lixo na praça",
      "Desperdiçar energia",
      "Cuidar dos espaços públicos",
    ],
    answer: 2,
  },
  {
    title: "Paz e Parcerias",
    subtitle: "Unir forças na missão final.",
    ids: [16, 17, 18],
    color: 4,
    question: "Como podemos fortalecer as parcerias?",
    options: [
      "Agindo sempre sozinhos",
      "Unindo a turma em uma ação",
      "Excluindo quem pensa diferente",
    ],
    answer: 1,
  },
  {
    title: "Mestre dos ODS",
    subtitle: "36 cartas. 3 minutos. Um grande impacto.",
    ids: Array.from({ length: 18 }, (_, i) => i + 1),
    color: 5,
    limit: 180,
    question: "Qual é a melhor forma de apoiar os ODS?",
    options: [
      "Esperar que outros ajam",
      "Cuidar apenas de si",
      "Praticar pequenas ações todos os dias",
    ],
    answer: 2,
  },
];

/* Identidade independente; não reutiliza o progresso de regras anteriores. */
Conecta.store = (() => {
  const key = "conecta-ods-v1";
  let data = {
    xp: 0,
    stars: Array(17).fill(0),
    best: Array(17).fill(null),
    globalSeal: false,
    sound: false,
  };
  let persistent = true;
  try {
    const raw = JSON.parse(localStorage.getItem(key));
    if (raw) {
      data.xp = Math.max(0, Math.floor(Number(raw.xp) || 0));
      data.stars = data.stars.map((_, i) =>
        Math.max(0, Math.min(3, Math.floor(Number(raw.stars?.[i]) || 0))),
      );
      data.best = data.best.map((_, i) =>
        Number.isInteger(raw.best?.[i]) && raw.best[i] > 0 ? raw.best[i] : null,
      );
      data.globalSeal = Boolean(raw.globalSeal) && data.stars.every(Boolean);
      data.sound = Boolean(raw.sound);
    }
  } catch {
    persistent = false;
  }
  const save = () => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch {
      persistent = false;
    }
  };
  return {
    data,
    save,
    get persistent() {
      return persistent;
    },
    get level() {
      return Math.floor(data.xp / 500) + 1;
    },
    get completed() {
      return data.stars.filter(Boolean).length;
    },
    unlocked(i) {
      return i >= 0 && i < 17 && data.stars.slice(0, i).every(Boolean);
    },
    complete(game) {
      const i = game.phase.id - 1;
      const globalBonus = i === 16 && !data.globalSeal ? 500 : 0;
      const reward = game.xp + game.precision + globalBonus;
      data.xp += reward;
      data.stars[i] = Math.max(data.stars[i], game.stars);
      data.best[i] =
        data.best[i] === null
          ? game.attempts
          : Math.min(data.best[i], game.attempts);
      if (globalBonus) data.globalSeal = true;
      save();
      return { reward, globalBonus };
    },
  };
})();

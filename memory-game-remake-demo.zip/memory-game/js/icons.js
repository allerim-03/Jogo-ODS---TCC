/* Ícones vetoriais locais: interface e conceitos das cartas. */
Conecta.icon = (name, cls = "") => {
  const shapes = {
    coat: '<path d="m13 4 7 6 7-6 10 9-6 8-4-4v20H13V17l-4 4-6-8zM20 10v27M17 4v5M23 4v5"/>',
    basket:
      '<path d="M4 17h32l-5 19H9zM10 17 17 4M30 17 23 4M14 23v7M20 23v7M26 23v7"/>',
    garden:
      '<path d="M3 34h34M20 34V16M20 23Q3 23 7 8q13-2 13 15M20 16Q20 1 35 4q2 12-15 12"/>',
    plate:
      '<circle cx="20" cy="20" r="11"/><path d="M3 4v13M1 17h5M3 17v20M37 3v34M34 4v14h3"/>',
    trash:
      '<path d="M8 12h24l-2 25H10zM5 8h30M15 8V3h10v5M16 18v12M24 18v12"/>',
    virus:
      '<circle cx="20" cy="20" r="11"/><path d="M20 1v8M20 31v8M1 20h8M31 20h8M6 6l6 6M28 28l6 6M6 34l6-6M28 12l6-6M16 16h1M25 19h1M19 26h1"/>',
    syringe:
      '<path d="m8 24 16-16 8 8-16 16zM4 36l8-8M25 3l12 12M27 11l4-4M16 17l4 4M12 21l4 4"/>',
    broom: '<path d="m29 3-12 22M11 21l14 8-6 9H2zM12 27l-5 8M17 30l-4 7"/>',
    brush:
      '<path d="M11 2h18v15H11zM11 12h18M17 17v7h-2v13h10V24h-2v-7M16 2v7M23 2v7"/>',
    heart: '<path d="M20 35 5 20C-4 8 10-3 20 9 30-3 44 8 35 20z"/>',
    tap: '<path d="M5 13h22q8 0 8 8v5h-9v-5H5zM16 13V5M9 5h14M32 30q-7 7 0 8 7-1 0-8"/>',
    rain: '<path d="M7 22a8 8 0 1 1 3-15A11 11 0 0 1 31 9a7 7 0 1 1 2 13H7M11 27l-3 8M21 27l-3 8M31 27l-3 8"/>',
    lightoff:
      '<path d="M13 27a13 13 0 0 1-4-18M14 4a13 13 0 0 1 13 23v6H13M15 38h10M2 2l36 36"/>',
    solar:
      '<path d="m6 17-4 16h36l-4-16zM14 17l-1 16M26 17l1 16M4 25h32M20 33v5M10 38h20"/><circle cx="20" cy="7" r="4"/><path d="M20 0v2M8 7h4M28 7h4"/>',
    factory:
      '<path d="M3 37V18l11 6V14l12 8V6h9v31zM8 30h3M17 30h3M29 30h2M27 2q-7 0-9-1"/>',

    home: '<path d="m5 15 15-12 15 12v20H24V24h-8v11H5z"/>',
    arrow: '<path d="M9 20h23M23 10l10 10-10 10"/>',
    back: '<path d="M31 20H8M17 10 7 20l10 10"/>',
    star: '<path d="m20 3 5 11 12 2-9 9 2 12-10-6-11 6 2-12-9-9 13-2z"/>',
    lock: '<rect x="9" y="17" width="22" height="19" rx="4"/><path d="M13 17v-6a7 7 0 0 1 14 0v6M20 25v4"/>',
    sound: '<path d="M5 15h7l9-8v26l-9-8H5zM27 13q9 7 0 14M31 7q15 13 0 26"/>',
    mute: '<path d="M5 15h7l9-8v26l-9-8H5zM28 15l9 10M37 15l-9 10"/>',
    album:
      '<rect x="7" y="4" width="28" height="32" rx="4"/><path d="M12 4v32M19 12h9M19 19h9M19 26h6M4 12h6M4 28h6"/>',
    medal:
      '<path d="m11 24-3 13 12-6 12 6-3-13"/><circle cx="20" cy="15" r="12"/><path d="m16 15 3 3 6-7"/>',
    pause: '<path d="M13 8v24M27 8v24"/>',
    replay: '<path d="M7 15a14 14 0 1 1 0 12M7 5v11h11"/>',
    help: '<circle cx="20" cy="20" r="16"/><path d="M15 14a5 5 0 1 1 7 5q-2 1-2 5M20 30v1"/>',
    check: '<path d="m8 20 8 9L33 10"/>',
    link: '<path d="m16 25-3 3a7 7 0 0 1-10-10l9-9a7 7 0 0 1 10 0M24 15l3-3a7 7 0 0 1 10 10l-9 9a7 7 0 0 1-10 0M13 27l14-14"/>',
    globe:
      '<circle cx="20" cy="20" r="17"/><ellipse cx="20" cy="20" rx="8" ry="17"/><path d="M4 14h32M4 26h32"/>',
    cold: '<path d="M20 3v34M5 12l30 16M5 28l30-16M15 6l5 5 5-5M15 34l5-5 5 5M5 18l8-2-1-8M35 22l-8 2 1 8"/>',
    food: '<path d="M5 19h30a15 15 0 0 1-30 0M7 35h26M13 6q-4 4 0 8M21 3q-4 5 0 10M29 6q-4 4 0 8"/>',
    book: '<path d="M20 10Q12 3 3 7v26q9-4 17 3 8-7 17-3V7q-9-4-17 3v26M8 14l7 1M25 15l7-1M8 22l7 1M25 23l7-1"/>',
    tree: '<path d="M20 2 6 18h7L3 29h34L27 18h7zM20 29v9"/>',
    recycle:
      '<path d="m13 11 7-8 9 13M26 7l3 9-10-1M32 20l5 12H20M26 26l-6 6 6 6M13 33H3l8-17M3 21l8-5 4 9"/>',
    health: '<path d="M15 4h10v11h11v10H25v11H15V25H4V15h11z"/>',
    play: '<circle cx="20" cy="20" r="17"/><path d="m20 11 9 6-3 10H14l-3-10zM20 3v8M36 15l-7 2M30 33l-4-6M10 33l4-6M4 15l7 2"/>',
    water:
      '<path d="M20 2S6 18 6 25a14 14 0 0 0 28 0C34 18 20 2 20 2zM12 25q0 7 7 7"/>',
    science:
      '<path d="M15 3h10M16 3v12L5 31q-3 6 5 6h20q8 0 5-6L24 15V3M10 25h20"/><circle cx="16" cy="30" r="1"/><circle cx="25" cy="32" r="1"/>',
    bulb: '<path d="M13 27a13 13 0 1 1 14 0v6H13zM15 38h10M20 31V18m-5-1 5 5 5-5"/>',
    sun: '<circle cx="20" cy="20" r="9"/><path d="M20 1v5M20 34v5M1 20h5M34 20h5M6 6l4 4M30 30l4 4M6 34l4-4M30 10l4-4"/>',
    shop: '<path d="M5 16v20h30V16M2 16l5-12h26l5 12q-5 7-10 0-8 7-16 0-5 7-10 0M14 36V24h12v12M20 4v12"/>',
    shield: '<path d="M20 2 5 8v12q0 11 15 18 15-7 15-18V8zM12 20l6 6 11-13"/>',
    tools:
      '<path d="M25 4a10 10 0 0 0-12 13L3 30a5 5 0 0 0 7 7l13-13A10 10 0 0 0 36 12l-8 7-7-7z"/>',
    wifi: '<path d="M3 13q17-17 34 0M9 21q11-11 22 0M15 28q5-5 10 0"/><circle cx="20" cy="35" r="2"/>',
    access:
      '<circle cx="18" cy="6" r="4"/><path d="M18 12v12h10l7 11M18 17h13M12 18a10 10 0 1 0 14 14"/>',
    chat: '<path d="M35 19a16 14 0 0 1-23 12L3 36l2-12A16 14 0 1 1 35 19zM10 14h18M10 21h12"/>',
    bus: '<rect x="7" y="3" width="26" height="30" rx="5"/><path d="M7 21h26M20 7v14M11 33v5M29 33v5M11 27h3M26 27h3"/>',
    bike: '<circle cx="9" cy="28" r="8"/><circle cx="31" cy="28" r="8"/><path d="m9 28 9-15 7 15H9M31 28 24 7h7M15 12h9"/>',
    bag: '<path d="M6 12h28l3 25H3zM13 15V9a7 7 0 0 1 14 0v6"/>',
    fish: '<path d="M4 20q15-19 25-4l9-8v24l-9-8Q19 39 4 20z"/><circle cx="13" cy="18" r="1"/>',
    animal:
      '<ellipse cx="20" cy="27" rx="9" ry="8"/><ellipse cx="7" cy="18" rx="4" ry="5"/><ellipse cx="15" cy="8" rx="4" ry="5"/><ellipse cx="27" cy="8" rx="4" ry="5"/><ellipse cx="35" cy="18" rx="4" ry="5"/>',
    fire: '<path d="M21 2q4 12 0 17l9-7q14 21 0 25H12Q-2 29 12 14q0 10 6 8z"/>',
    vote: '<path d="m12 4 14-2 3 14-14 3zM13 15H7L3 26v11h34V26l-5-11h-3M3 26h34M12 22h16"/>',
    people:
      '<circle cx="20" cy="9" r="6"/><path d="M10 36v-9a10 10 0 0 1 20 0v9M7 8a5 5 0 0 0 0 10M5 22q-5 1-4 12M33 8a5 5 0 0 1 0 10M35 22q5 1 4 12"/>',
  };
  return `<svg class="icon ${cls}" viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${shapes[name] || shapes.globe}</svg>`;
};

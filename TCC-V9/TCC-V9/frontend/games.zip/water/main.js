let jogo1RunId = crypto.randomUUID();
const canvas = document.getElementById("canvas-jogo-1");
const ctx = canvas.getContext("2d");

let estado = "menu"; // "menu", "jogando", "gameover"

// Botão PLAY centralizado perfeitamente entre os personagens e abaixo do título
// Centralizado no meio (x = 320) e posicionado verticalmente abaixo do título (y = 210 ou 220)
const botaoPlay = { x: 225, y: 230, largura: 160, altura: 60 };
const botaoReplay = { x: 320, y: 220, largura: 160, altura: 50 };

// Disparado quando o jogador colide com a água
function dispararMorte() {
    estado = "gameover";
    jogadorJogo1.estaMorto = true;
}

// Reinicia todas as variáveis para uma nova tentativa
function reiniciarJogo() {
    jogo1RunId = crypto.randomUUID();
    jogadorJogo1.resetar();
    plataformasJogo1.resetar();
    
    // Reseta o estado do gerenciador de interativos
    interativosJogo1.itens = [];
    interativosJogo1.contadorConcluidos = 0;
    interativosJogo1.tempoUltimoItem = 0;
    interativosJogo1.proximaDistancia = 800;

    // Reseta o estado do NPC
    if (typeof npcGuri !== "undefined") {
        npcGuri.emConversa = false;
        npcGuri.jaConversou = false;
    }

    estado = "jogando";
}

// Loop principal de renderização e física
function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (estado === "menu") {
        cenarioJogo1.desenharMenu(ctx, canvas.width, canvas.height, botaoPlay);
    } 

    if (estado === "jogando") {
        // 1. Lógica e Física
        jogadorJogo1.atualizar(cenarioJogo1.alturaChao);
        cenarioJogo1.atualizarCamera(jogadorJogo1.x, canvas.width);
        plataformasJogo1.atualizar(jogadorJogo1, dispararMorte);
        
        // Atualiza a lógica do NPC (distância e diálogo por Espaço/Enter)
        if (typeof npcGuri !== "undefined") {
            npcGuri.atualizar(jogadorJogo1);
        }

        // Atualiza itens interativos
        interativosJogo1.atualizar(
            jogadorJogo1,
            plataformasJogo1.listaPocas,
            plataformasJogo1.listaPlataformas
        );

        // 2. Renderização
        cenarioJogo1.desenharJogo(ctx, canvas.width, canvas.height);
        plataformasJogo1.desenhar(ctx, cenarioJogo1.cameraX);
        
        // Desenha o NPC no cenário
        if (typeof npcGuri !== "undefined") {
            npcGuri.desenhar(ctx, cenarioJogo1.cameraX);
        }

        interativosJogo1.desenhar(ctx, cenarioJogo1.cameraX, jogadorJogo1);
        jogadorJogo1.desenhar(ctx, cenarioJogo1.cameraX);
        
        // 3. HUD e Diálogos
        interativosJogo1.desenharHUD(ctx, canvas.width);

        // Desenha a caixa de diálogo por cima da tela
        if (typeof npcGuri !== "undefined") {
            npcGuri.desenharDialogo(ctx, canvas.width, canvas.height);
        }
    }

    // Tela de Game Over (Congela o estado atual do jogo no fundo)
    if (estado === "gameover") {
        cenarioJogo1.desenharJogo(ctx, canvas.width, canvas.height);
        plataformasJogo1.desenhar(ctx, cenarioJogo1.cameraX);
        
        if (typeof npcGuri !== "undefined") {
            npcGuri.desenhar(ctx, cenarioJogo1.cameraX);
        }

        interativosJogo1.desenhar(ctx, cenarioJogo1.cameraX, jogadorJogo1);
        jogadorJogo1.desenhar(ctx, cenarioJogo1.cameraX);

        // Overlay escuro
        ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Mensagem de alerta
        ctx.fillStyle = "#e74c3c";
        ctx.font = "bold 38px Arial";
        ctx.textAlign = "center";
        ctx.fillText("OH NÃO!", canvas.width / 2, 140);

        ctx.fillStyle = "#ffffff";
        ctx.font = "18px Arial";
        ctx.fillText("Você caiu na poça d'água!", canvas.width / 2, 180);

        // Botão REPLAY
        ctx.fillStyle = "#e67e22";
        ctx.fillRect(botaoReplay.x, botaoReplay.y, botaoReplay.largura, botaoReplay.altura);
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.strokeRect(botaoReplay.x, botaoReplay.y, botaoReplay.largura, botaoReplay.altura);

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 22px Arial";
        ctx.fillText("REPLAY", canvas.width / 2, botaoReplay.y + 33);
    }

    requestAnimationFrame(loop);
}

// Escuta cliques do mouse apenas para os botões do Menu e Game Over
canvas.addEventListener("click", (e) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    if (estado === "menu") {
        if (
            mouseX >= botaoPlay.x && mouseX <= botaoPlay.x + botaoPlay.largura &&
            mouseY >= botaoPlay.y && mouseY <= botaoPlay.y + botaoPlay.altura
        ) {
            estado = "jogando";
        }
    }

    if (estado === "gameover") {
        if (
            mouseX >= botaoReplay.x && mouseX <= botaoReplay.x + botaoReplay.largura &&
            mouseY >= botaoReplay.y && mouseY <= botaoReplay.y + botaoReplay.altura
        ) {
            reiniciarJogo();
        }
    }
});

// Inicialização
loop();